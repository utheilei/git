#ifndef CHOICEISO_H
#define CHOICEISO_H

#include <QWidget>
#include <dfilechooseredit.h>

DWIDGET_USE_NAMESPACE

class ChoiceISO : public QWidget
{
    Q_OBJECT
public:
    explicit ChoiceISO(QWidget *parent = nullptr);

signals:
    void signalClicked(int row);

public slots:
};

#endif // CHOICEISO_H
