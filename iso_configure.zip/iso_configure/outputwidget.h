#ifndef OUTPUTWIDGET_H
#define OUTPUTWIDGET_H

#include <QWidget>
#include <DLabel>

DWIDGET_USE_NAMESPACE

class OutputWidget : public QWidget
{
    Q_OBJECT
public:
    explicit OutputWidget(QWidget *parent = nullptr);

signals:

public slots:

private:
    int count = 0;
};

#endif // OUTPUTWIDGET_H
