#include "clearwidget.h"
#include <DFontSizeManager>
#include <DCommandLinkButton>
#include <DPushButton>
#include <QBoxLayout>
#include <DFileDialog>

ClearWidget::ClearWidget(QWidget *parent) : QWidget(parent)
{
    DLabel *label = new DLabel(this);
    QFont font("SimHei");
    font.setBold(true);
    label->setFont(font);
    DFontSizeManager::instance()->bind(label, DFontSizeManager::T3);
    label->setText(tr("后期清理"));

    DCommandLinkButton *clearbtn = new DCommandLinkButton(tr("全部清除"),this);
    clearbtn->hide();

    QHBoxLayout *hlayout = new QHBoxLayout;
    hlayout->addWidget(label);
    hlayout->addWidget(clearbtn);
    hlayout->setAlignment(clearbtn,Qt::AlignRight);

    QWidget *pDGroupBox = new QWidget(this);
    pDGroupBox->setFixedHeight(400);
    QVBoxLayout *pVBoxLayoutCheck = new QVBoxLayout;
    pVBoxLayoutCheck->setSpacing(0);
    pDGroupBox->setLayout(pVBoxLayoutCheck);

    DLabel *label1 = new DLabel(this);
    QFont font1("SimHei");
    label1->setFont(font1);
    DFontSizeManager::instance()->bind(label1, DFontSizeManager::T2);
    label1->setText(tr("请选择后期清理"));
    label1->setEnabled(false);
    pVBoxLayoutCheck->addWidget(label1);
    pVBoxLayoutCheck->setAlignment(label1,Qt::AlignCenter);

    DCommandLinkButton *registerbtn = new DCommandLinkButton(tr("选择脚本"),this);

    DPushButton *btn = new DPushButton(tr("下一步"),this);
    btn->setFixedSize(300,35);

    QVBoxLayout *layout = new QVBoxLayout;
    this->setLayout(layout);
    layout->setContentsMargins(35,30,35,30);

    layout->addLayout(hlayout);
    layout->addWidget(pDGroupBox);
    layout->addWidget(registerbtn);
    layout->setAlignment(registerbtn,Qt::AlignHCenter);
    layout->addWidget(btn);
    layout->setAlignment(btn,Qt::AlignHCenter);

    connect(registerbtn,&DCommandLinkButton::clicked,[=](){
        DFileDialog *pDFileDialog = new DFileDialog();
        pDFileDialog->setAcceptMode(QFileDialog::AcceptOpen); //文件对话框为打开文件类型
        pDFileDialog->setNameFilter(tr("*.job"));
        //QString filename = QFileDialog::getOpenFileName(nullptr,"Please Select File","./","*.deb");
        if(pDFileDialog->exec()==QDialog::Accepted)
        {
            clearbtn->show();
            QStringList strlistSelectedName = pDFileDialog->selectedFiles();
            pDFloatMessage = new DFloatingMessage(DFloatingMessage::ResidentType, this);
            //pDFloatMessage->setMinimumHeight(50);
            pDFloatMessage->setIcon(QIcon(":/images/progress.svg"));
            pDFloatMessage->setMessage(strlistSelectedName[0]);
            pDFloatMessage->show();
            m_floatingMessage.append(pDFloatMessage);
            label1->hide();
            pVBoxLayoutCheck->addWidget(pDFloatMessage);
            pVBoxLayoutCheck->setAlignment(pDFloatMessage,Qt::AlignTop);
        }
    });

    connect(clearbtn,&DCommandLinkButton::clicked,[=](){
        for (int i=0;i<m_floatingMessage.size();i++) {
            m_floatingMessage[i]->close();
        }
        label1->show();
        clearbtn->hide();
    });

    connect(btn,&DPushButton::clicked,[=](){
        emit signalClicked(5);
    });
}
