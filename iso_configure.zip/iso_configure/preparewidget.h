#ifndef PREPAREWIDGET_H
#define PREPAREWIDGET_H

#include <QWidget>
#include <DLabel>
#include <DFloatingMessage>

DWIDGET_USE_NAMESPACE

class PrepareWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PrepareWidget(QWidget *parent = nullptr);

signals:
    void signalClicked(int row);

public slots:

private:
    DFloatingMessage *pDFloatMessage;
    QVector<DFloatingMessage *> m_floatingMessage;
};

#endif // PREPAREWIDGET_H
