#include "choiceiso.h"
#include <QBoxLayout>
#include <DLabel>
#include <DFontSizeManager>
#include <DPushButton>

ChoiceISO::ChoiceISO(QWidget *parent) : QWidget(parent)
{
    DLabel *label = new DLabel(this);
    QFont font("SimHei");
    font.setBold(true);
    label->setFont(font);
    DFontSizeManager::instance()->bind(label, DFontSizeManager::T3);
    label->setText(tr("选择ISO"));

    DFileChooserEdit *fileEdit = new DFileChooserEdit();
    fileEdit->setNameFilters(QStringList("ISO(*.iso)"));

    DPushButton *btn = new DPushButton(tr("下一步"),this);
    btn->setFixedSize(300,35);
    btn->setEnabled(false);

    QVBoxLayout *layout = new QVBoxLayout;
    this->setLayout(layout);
    layout->setContentsMargins(35,30,35,30);

    layout->addWidget(label);
    layout->addWidget(fileEdit);
    layout->addStretch();
    layout->addWidget(btn);
    layout->setAlignment(btn,Qt::AlignHCenter);

    connect(fileEdit,&DFileChooserEdit::fileChoosed,[=](const QString &fileName){
        if(!fileName.isEmpty()){
            btn->setEnabled(true);
        }
    });

    connect(btn,&DPushButton::clicked,[=](){
        emit signalClicked(0);
    });
}
