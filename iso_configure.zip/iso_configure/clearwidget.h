#ifndef CLEARWIDGET_H
#define CLEARWIDGET_H

#include <QWidget>
#include <DLabel>
#include <DFloatingMessage>

DWIDGET_USE_NAMESPACE

class ClearWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ClearWidget(QWidget *parent = nullptr);

signals:
    void signalClicked(int row);

public slots:

private:
    DFloatingMessage *pDFloatMessage;
    QVector<DFloatingMessage *> m_floatingMessage;
};

#endif // CLEARWIDGET_H
