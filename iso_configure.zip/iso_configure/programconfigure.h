#ifndef PROGRAMCONFIGURE_H
#define PROGRAMCONFIGURE_H

#include <QWidget>
#include <DLabel>
#include <DFloatingMessage>

DWIDGET_USE_NAMESPACE

class ProgramConfigure : public QWidget
{
    Q_OBJECT
public:
    explicit ProgramConfigure(QWidget *parent = nullptr);

signals:
    void signalClicked(int row);

public slots:

private:
    DFloatingMessage *pDFloatMessage;
    QVector<DFloatingMessage *> m_floatingMessage;
};

#endif // PROGRAMCONFIGURE_H
