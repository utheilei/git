#include "listwidget.h"
#include <QStandardItemModel>
#include <QStandardItem>

ListWidget::ListWidget(QWidget *parent) : DListView(parent)
{
    itemModel = new QStandardItemModel;
    QStandardItem *choiceiso = new QStandardItem(QIcon::fromTheme("iso_inactive1"),tr("选择ISO"));
    //choiceiso->setSizeHint(QSize(this->width(),50));
    choiceiso->setEnabled(true);
    //choiceiso->setData(true,Qt::UserRole+1);
    itemModel->appendRow(choiceiso);

    QStandardItem *framework = new QStandardItem(QIcon::fromTheme("iso_inactive2"),tr("选择架构"));
    //framework->setSizeHint(QSize(this->width(),50));
    framework->setEnabled(false);
    //framework->setData(false,Qt::UserRole+1);
    itemModel->appendRow(framework);

    QStandardItem *configure = new QStandardItem(QIcon::fromTheme("iso_inactive3"),tr("程序配置"));
    //configure->setSizeHint(QSize(this->width(),50));
    configure->setEnabled(false);
    //configure->setData(false,Qt::UserRole+1);
    itemModel->appendRow(configure);

    QStandardItem *prepare = new QStandardItem(QIcon::fromTheme("iso_inactive4"),tr("前期准备"));
    //prepare->setSizeHint(QSize(this->width(),50));
    prepare->setEnabled(false);
    //prepare->setData(false,Qt::UserRole+1);
    itemModel->appendRow(prepare);

    QStandardItem *install = new QStandardItem(QIcon::fromTheme("iso_inactive5"),tr("中期安装"));
    //install->setSizeHint(QSize(this->width(),50));
    install->setEnabled(false);
    //install->setData(false,Qt::UserRole+1);
    itemModel->appendRow(install);

    QStandardItem *clear = new QStandardItem(QIcon::fromTheme("iso_inactive6"),tr("后期清理"));
    //clear->setSizeHint(QSize(this->width(),50));
    clear->setEnabled(false);
    //clear->setData(false,Qt::UserRole+1);
    itemModel->appendRow(clear);

    QStandardItem *kernel = new QStandardItem(QIcon::fromTheme("iso_inactive7"),tr("选择Kernel"));
    //kernel->setSizeHint(QSize(this->width(),50));
    kernel->setEnabled(false);
    //kernel->setData(false,Qt::UserRole+1);
    itemModel->appendRow(kernel);

    QStandardItem *output = new QStandardItem(QIcon::fromTheme("iso_inactive8"),tr("输出"));
    //output->setSizeHint(QSize(this->width(),50));
    output->setEnabled(false);
    //output->setData(false,Qt::UserRole+1);
    itemModel->appendRow(output);

    this->setModel(itemModel);
}

QStandardItemModel *ListWidget::getItemModel()
{
    return itemModel;
}
