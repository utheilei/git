#include "outputwidget.h"
#include <DWaterProgress>
#include <DFontSizeManager>
#include <DPushButton>
#include <QBoxLayout>
#include <QTimer>

OutputWidget::OutputWidget(QWidget *parent) : QWidget(parent)
{
    DLabel *label = new DLabel(this);
    QFont font("SimHei");
    font.setBold(true);
    label->setFont(font);
    DFontSizeManager::instance()->bind(label, DFontSizeManager::T3);
    label->setText(tr("准备输出"));

    DWaterProgress *waterProgress = new DWaterProgress(this);
    waterProgress->setFixedSize(100,100);
    waterProgress->start();
    waterProgress->setValue(0);

    DPushButton *btn = new DPushButton(tr("下一步"),this);
    btn->setFixedSize(300,35);

    QVBoxLayout *layout = new QVBoxLayout;
    this->setLayout(layout);
    layout->setContentsMargins(35,30,35,30);

    layout->addWidget(label);
    layout->setAlignment(label,Qt::AlignHCenter);
    layout->addStretch();
    layout->addWidget(waterProgress);
    layout->setAlignment(waterProgress,Qt::AlignHCenter);
    layout->addStretch();
    layout->addWidget(btn);
    layout->setAlignment(btn,Qt::AlignHCenter);

    QTimer *timer = new QTimer;
    timer->setInterval(200);
    connect(timer,&QTimer::timeout,[=](){
        count++;
        if(count>99){
            timer->stop();
        }
        waterProgress->setValue(count);
    });

    connect(btn,&DPushButton::clicked,[=](){
        timer->start();
    });
}
