#include "programconfigure.h"
#include <DFontSizeManager>
#include <DPushButton>
#include <QBoxLayout>
#include <DFileDialog>
#include <QFileInfo>
#include <QFileIconProvider>
#include <QDebug>

ProgramConfigure::ProgramConfigure(QWidget *parent) : QWidget(parent)
                ,m_signalMapper(new QSignalMapper(this))
{
    DLabel *label = new DLabel(this);
    QFont font("SimHei");
    font.setBold(true);
    label->setFont(font);
    DFontSizeManager::instance()->bind(label, DFontSizeManager::T3);
    label->setText(tr("程序配置"));

    clearbtn = new DCommandLinkButton(tr("全部清除"),this);
    clearbtn->hide();

    QHBoxLayout *hlayout = new QHBoxLayout;
    hlayout->addWidget(label);
    hlayout->addWidget(clearbtn);
    hlayout->setAlignment(clearbtn,Qt::AlignRight);

    QWidget *pDGroupBox = new QWidget(this);
    //pDGroupBox->setFixedHeight(400);
    QVBoxLayout *pVBoxLayoutCheck = new QVBoxLayout;
    pVBoxLayoutCheck->setSpacing(0);
    pDGroupBox->setLayout(pVBoxLayoutCheck);

    label1 = new DLabel(this);
    QFont font1("SimHei");
    label1->setFont(font1);
    DFontSizeManager::instance()->bind(label1, DFontSizeManager::T2);
    label1->setText(tr("请选择程序"));
    label1->setEnabled(false);
//    pVBoxLayoutCheck->addWidget(label1);
//    pVBoxLayoutCheck->setAlignment(label1,Qt::AlignCenter);

    DCommandLinkButton *registerbtn = new DCommandLinkButton(tr("选择程序deb包"),this);

    DPushButton *btn = new DPushButton(tr("下一步"),this);
    btn->setFixedSize(300,35);

    QVBoxLayout *layout = new QVBoxLayout;
    this->setLayout(layout);
    layout->setContentsMargins(35,30,35,30);

    layout->addLayout(hlayout);
    layout->addWidget(pDGroupBox);
    layout->addStretch();
    layout->addWidget(label1);
    layout->setAlignment(label1,Qt::AlignHCenter);
    layout->addStretch();
    layout->addWidget(registerbtn);
    layout->setAlignment(registerbtn,Qt::AlignHCenter);
    layout->addWidget(btn);
    layout->setAlignment(btn,Qt::AlignHCenter);

    connect(registerbtn,&DCommandLinkButton::clicked,[=](){
        DFileDialog *pDFileDialog = new DFileDialog();
        pDFileDialog->setAcceptMode(QFileDialog::AcceptOpen); //文件对话框为打开文件类型
        pDFileDialog->setFileMode(QFileDialog::ExistingFiles);
        pDFileDialog->setNameFilter(tr("*.deb"));
        //QString filename = QFileDialog::getOpenFileName(nullptr,"Please Select File","./","*.deb");
        if(pDFileDialog->exec()==QDialog::Accepted)
        {
            clearbtn->show();
            label1->hide();
            QStringList strlistSelectedName = pDFileDialog->selectedFiles();
            for (int i=0;i<strlistSelectedName.size();i++) {
                pDFloatMessage = new DFloatingMessage(DFloatingMessage::ResidentType, this);
                pDFloatMessage->setIcon(getIcon(strlistSelectedName[i]));
                pDFloatMessage->setMessage(strlistSelectedName[i]);
                pDFloatMessage->show();
                m_floatingMessage.append(pDFloatMessage);
                pVBoxLayoutCheck->addWidget(pDFloatMessage);
                pVBoxLayoutCheck->setAlignment(pDFloatMessage,Qt::AlignTop);
                connect(pDFloatMessage, SIGNAL(closeButtonClicked()), m_signalMapper, SLOT(map()));
                m_signalMapper->setMapping(pDFloatMessage,pDFloatMessage);
            }
        }
    });

    connect(clearbtn,&DCommandLinkButton::clicked,[=](){
        for (int i=0;i<m_floatingMessage.size();i++) {
            m_floatingMessage[i]->close();
        }
        label1->show();
        clearbtn->hide();
    });

    connect(btn,&DPushButton::clicked,[=](){
        emit signalClicked(2);
    });

    connect(m_signalMapper,SIGNAL(mapped(QWidget*)),this,SLOT(slotSignalMap(QWidget*)));
}

QIcon ProgramConfigure::getIcon(QString filename)
{
    QFileInfo file_info(filename);
    QFileIconProvider file_icon;
    QIcon icon = file_icon.icon(file_info);
    return icon;
}

void ProgramConfigure::slotSignalMap(QWidget *w)
{
    DFloatingMessage *message = qobject_cast<DFloatingMessage*>(w);
    message->close();
    m_floatingMessage.removeOne(message);
    if(m_floatingMessage.isEmpty()){
        label1->show();
        clearbtn->hide();
    }
}
