#ifndef INSTALLWIDGET_H
#define INSTALLWIDGET_H

#include <QWidget>
#include <DLabel>
#include <DFloatingMessage>
#include <DCommandLinkButton>
#include <QSignalMapper>

DWIDGET_USE_NAMESPACE

class InstallWidget : public QWidget
{
    Q_OBJECT
public:
    explicit InstallWidget(QWidget *parent = nullptr);
    QIcon getIcon(QString filename);

signals:
    void signalClicked(int row);

public slots:
    void slotSignalMap(QWidget *w);

private:
    DFloatingMessage *pDFloatMessage;
    QVector<DFloatingMessage *> m_floatingMessage;
    QSignalMapper *m_signalMapper;
    DCommandLinkButton *clearbtn;
    DLabel *label1;
};

#endif // INSTALLWIDGET_H
