#ifndef INSTALLWIDGET_H
#define INSTALLWIDGET_H

#include <QWidget>
#include <DLabel>
#include <DFloatingMessage>

DWIDGET_USE_NAMESPACE

class InstallWidget : public QWidget
{
    Q_OBJECT
public:
    explicit InstallWidget(QWidget *parent = nullptr);

signals:
    void signalClicked(int row);

public slots:

private:
    DFloatingMessage *pDFloatMessage;
    QVector<DFloatingMessage *> m_floatingMessage;
};

#endif // INSTALLWIDGET_H
