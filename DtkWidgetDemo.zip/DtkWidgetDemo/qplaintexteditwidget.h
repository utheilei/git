#ifndef QPLAINTEXTEDITWIDGET_H
#define QPLAINTEXTEDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPlainTextEdit>

class QPlainTextEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QPlainTextEditWidget(QWidget *parent = nullptr);
    ~QPlainTextEditWidget();

signals:

public slots:
};

#endif // QPLAINTEXTEDITWIDGET_H
