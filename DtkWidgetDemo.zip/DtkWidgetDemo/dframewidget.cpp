#include "dframewidget.h"

DFrameWidget::DFrameWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DFrame *pDFrame = new DFrame();
    pDFrame->setMinimumSize(200, 200);
    pDFrame->setFrameRounded(true);
    pDFrame->setBackgroundRole(DPalette::LightLively);

    DPalette pa = DApplicationHelper::instance()->palette(pDFrame);
    QColor color = pa.lightLively().color();
    pa.setColor(DPalette::Base, color);
    DApplicationHelper::instance()->setPalette(pDFrame, pa);

    pHBoxLayout->addWidget(pDFrame);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DFrame *pDFrame1 = new DFrame();
    pDFrame1->setMinimumSize(200, 200);
    pDFrame1->setFrameRounded(false);



    pHBoxLayout2->addWidget(pDFrame1);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DFrameWidget::~DFrameWidget()
{

}
