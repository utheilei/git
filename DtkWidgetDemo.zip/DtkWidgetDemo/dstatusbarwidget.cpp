#include "dstatusbarwidget.h"

DStatusBarWidget::DStatusBarWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DPushButton *pDPushButton = new DPushButton(QStringLiteral("DStatus应用1"),this);
    pDPushButton->setFixedSize(250, 36);
    connect(pDPushButton, &DPushButton::clicked, this, &DStatusBarWidget::slotDPuBtnClicked);
    pHBoxLayout->addWidget(pDPushButton);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DPushButton *pDPushButton2 = new DPushButton(QStringLiteral("DStatus应用2"));
    pDPushButton2->setFixedSize(250, 36);
    connect(pDPushButton2, &DPushButton::clicked, this, &DStatusBarWidget::slotDPuBtn2Clicked);
    pHBoxLayout2->addWidget(pDPushButton2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

void DStatusBarWidget::slotDPuBtnClicked()
{
    m_pMainWindow = new DMainWindow();
    m_pMainWindow->setMinimumSize(600, 400);
    m_pMainWindow->statusBar()->setSizeGripEnabled(true);

    m_pDWidget = new DWidget();

    DPalette pa = DApplicationHelper::instance()->palette(m_pMainWindow->statusBar());
    QColor color = pa.link().color();
    pa.setColor(QPalette::Background, color);
    m_pDWidget->setPalette(pa);

    m_pDWidget->setMinimumWidth(600);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setMargin(2);
    pHBoxLayout->addStretch();

    DPushButton *pDPushBtn = new DPushButton(QStringLiteral("上一页"));
    pHBoxLayout->addWidget(pDPushBtn);
    DPushButton *pDPushBtn2 = new DPushButton(QStringLiteral("下一页"));
    pHBoxLayout->addWidget(pDPushBtn2);

    DLabel *pDLabel = new DLabel(QStringLiteral("7项"));
    pDLabel->setMinimumSize(pDLabel->sizeHint());
    pDLabel->setAlignment(Qt::AlignCenter);
    pHBoxLayout->addWidget(pDLabel);

    DSlider *pDSlider = new DSlider(Qt::Horizontal);
    pDSlider->setMinimum(0);
    pDSlider->setMaximum(100);
    pDSlider->setValue(40);
    pHBoxLayout->addWidget(pDSlider);

    pHBoxLayout->addStretch();
    m_pDWidget->setLayout(pHBoxLayout);
    m_pMainWindow->statusBar()->addWidget(m_pDWidget);

    m_pMainWindow->show();
}

void DStatusBarWidget::slotDPuBtn2Clicked()
{
    DMainWindow *pMainWindow = new DMainWindow();
    pMainWindow->setMinimumSize(600, 400);
    pMainWindow->statusBar()->setSizeGripEnabled(true);
    pMainWindow->statusBar()->showMessage(QStringLiteral("这是showMessage信息"), 3000);

    pMainWindow->show();
}

void DStatusBarWidget::resizeEvent(QResizeEvent *event)
{
    //m_pMainWindow->statusBar()->setFixedWidth(this->width());
    //m_pDWidget->resize(this->width(), m_pDWidget->height());

    //DMainWindow::resizeEvent(event);
}
