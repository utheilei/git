#include "dsuggestbuttonwidget.h"



DSuggestButtonWidget::DSuggestButtonWidget(QWidget *parent)
    : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();

    DSuggestButton *pDSuggestButton1 = new DSuggestButton("所有照片");
    pDSuggestButton1->setMinimumWidth(120);
    connect(pDSuggestButton1, &DSuggestButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    pDSuggestButton1->setMaximumWidth(150);
    pHBoxLayout->addWidget(pDSuggestButton1);

    DSuggestButton *pDSuggestButton2 = new DSuggestButton("DSuggestButton");
    pDSuggestButton2->setMaximumWidth(150);
    pHBoxLayout->addWidget(pDSuggestButton2);
    pDSuggestButton2->setDisabled(true);

    DSuggestButton *pDSuggestButton3 = new DSuggestButton(tr("继续安装"));
    pDSuggestButton3->setMinimumWidth(150);
    pHBoxLayout->addWidget(pDSuggestButton3);
    pDSuggestButton3->setFocusPolicy(Qt::StrongFocus);

    DSuggestButton *pDSuggestButton4 = new DSuggestButton(tr("继续安装"));
    pDSuggestButton4->setMinimumWidth(150);
    pHBoxLayout->addWidget(pDSuggestButton4);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}

DSuggestButtonWidget::~DSuggestButtonWidget()
{

}
