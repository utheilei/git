#ifndef DFILECHOOSEREDITWIDGET_H
#define DFILECHOOSEREDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <dfilechooseredit.h>

DWIDGET_USE_NAMESPACE

class DFileChooserEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DFileChooserEditWidget(QWidget *parent = nullptr);
    ~DFileChooserEditWidget();

signals:

public slots:
};

#endif // DFILECHOOSEREDITWIDGET_H
