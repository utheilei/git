#include "dlineeditwidget.h"

DLineEditWidget::DLineEditWidget(QWidget *parent) : QWidget(parent)
{

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->addStretch();
    DLineEdit *pDLineEdit = new DLineEdit();
    pHBoxLayout1->addWidget(pDLineEdit);
    pHBoxLayout1->addStretch();
    pMainLayout->addLayout(pHBoxLayout1);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DLineEdit *pDLineEdit2 = new DLineEdit();
    //pDLineEdit2->setText(tr("默认显示"));
    pDLineEdit2->lineEdit()->setPlaceholderText(tr("请输入密码"));
    pDLineEdit2->setAlert(false);
    //pDLineEdit2->showAlertMessage("knog", 30000);
    QList<QWidget *> listWidget;
    DIconButton *pDIconBtn = new DIconButton(DStyle::SP_IncreaseElement);
    pDIconBtn->setFixedSize(40, 40);
    listWidget.append(pDIconBtn);
    DIconButton *pDIconBtn2 = new DIconButton(DStyle::SP_DecreaseElement);
    pDIconBtn2->setFixedSize(40, 40);
    listWidget.append(pDIconBtn2);
    pDLineEdit2->setRightWidgets(listWidget);
    pHBoxLayout2->addWidget(pDLineEdit2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    QList<QWidget *> listWidget2;
    DIconButton *pDIconBtn3 = new DIconButton(DStyle::SP_IncreaseElement);
    pDIconBtn3->setFixedSize(40, 40);
    listWidget2.append(pDIconBtn3);
    DIconButton *pDIconBtn4 = new DIconButton(DStyle::SP_DecreaseElement);
    pDIconBtn4->setFixedSize(40, 40);
    listWidget2.append(pDIconBtn4);
    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->addStretch();

    m_pDLineEdit3 = new DLineEdit();
    connect(m_pDLineEdit3, &DLineEdit::editingFinished, this, [=] {
        if (m_pDLineEdit3->text().isEmpty()) {
            m_pDLineEdit3->showAlertMessage(tr("请输入密码"));
        }
    });
    m_pDLineEdit3->setRightWidgets(listWidget2);
    pHBoxLayout3->addWidget(m_pDLineEdit3);
    pHBoxLayout3->addStretch();
    pMainLayout->addLayout(pHBoxLayout3);

    QHBoxLayout *pHBoxLayout4 = new QHBoxLayout();
    pHBoxLayout4->addStretch();
    DPushButton *pDpushBtn = new DPushButton(QStringLiteral("登录"));
    pDpushBtn->setFixedWidth(70);
    connect(pDpushBtn, &DPushButton::clicked, this, &DLineEditWidget::slotDpushBtnClicked);
    pHBoxLayout4->addWidget(pDpushBtn);
    pHBoxLayout4->addStretch();
    pMainLayout->addLayout(pHBoxLayout4);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DLineEditWidget::~DLineEditWidget()
{

}

void DLineEditWidget::slotDpushBtnClicked()
{
    if(m_pDLineEdit3->text() == "")
    {
        m_pDLineEdit3->setAlert(true);
        m_pDLineEdit3->showAlertMessage(QStringLiteral("不能为空"));
    }
}
