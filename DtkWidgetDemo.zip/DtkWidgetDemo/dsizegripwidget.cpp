#include "dsizegripwidget.h"

DSizegripWidget::DSizegripWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DPushButton *pDPushButton = new DPushButton(QStringLiteral("DSizegrip应用DMainWindow"));
    pDPushButton->setFixedSize(250, 36);
    connect(pDPushButton, &DPushButton::clicked, this, &DSizegripWidget::slotDPuBtnClicked);
    pHBoxLayout->addWidget(pDPushButton);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DPushButton *pDPushButton2 = new DPushButton(QStringLiteral("DSizegrip应用DDialog"));
    pDPushButton2->setFixedSize(250, 36);
    connect(pDPushButton2, &DPushButton::clicked, this, &DSizegripWidget::slotDPuBtn2Clicked);
    pHBoxLayout2->addWidget(pDPushButton2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

void DSizegripWidget::slotDPuBtnClicked()
{
    DMainWindow *w = new DMainWindow();
    w->setMinimumSize(600, 400);
    w->statusBar()->setSizeGripEnabled(true);
    w->show();
}

void DSizegripWidget::slotDPuBtn2Clicked()
{
    DDialog *pDialog = new DDialog(QStringLiteral("警告/提示"), QStringLiteral("是否确认删除该文件？"));
    pDialog->show();
}
