#include "dkeysequenceeditwidget.h"

DKeySequenceEditWidget::DKeySequenceEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(10);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->addWidget(new DLabel(tr("快键键1：")));
    DKeySequenceEdit *pDKeySeqEdit = new DKeySequenceEdit();
    pDKeySeqEdit->ShortcutDirection(Qt::AlignLeft);
    connect(pDKeySeqEdit, &DKeySequenceEdit::editingFinished, this, [=](const QKeySequence &keySequence) {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), keySequence.toString());
    });
    pHBoxLayout->addWidget(pDKeySeqEdit);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    pHBoxLayout2->addWidget(new DLabel(tr("快键键2：")));
    DKeySequenceEdit *pDKeySeqEdit2 = new DKeySequenceEdit();
    pDKeySeqEdit2->ShortcutDirection(Qt::AlignLeft);
    connect(pDKeySeqEdit2, &DKeySequenceEdit::editingFinished, this, [=](const QKeySequence &keySequence) {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), keySequence.toString());
    });
    pHBoxLayout2->addWidget(pDKeySeqEdit2);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->addStretch();
    pHBoxLayout3->addWidget(new DLabel(tr("快键键3：")));
    DKeySequenceEdit *pDKeySeqEdit3 = new DKeySequenceEdit();
    pDKeySeqEdit3->ShortcutDirection(Qt::AlignLeft);
    connect(pDKeySeqEdit3, &DKeySequenceEdit::editingFinished, this, [=](const QKeySequence &keySequence) {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), keySequence.toString());
    });
    pHBoxLayout3->addWidget(pDKeySeqEdit3);
    pHBoxLayout3->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout3);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DKeySequenceEditWidget::~DKeySequenceEditWidget()
{

}
