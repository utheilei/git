#ifndef DFLOATINGBUTTONWIDGET_H
#define DFLOATINGBUTTONWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DFloatingButton>
#include <DApplicationHelper>
#include <DMessageManager>
#include <DPalette>
#include <DGuiApplicationHelper>

DGUI_USE_NAMESPACE
DWIDGET_USE_NAMESPACE

class DFloatingButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DFloatingButtonWidget(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DFLOATINGBUTTONWIDGET_H
