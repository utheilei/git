#ifndef DSPINBOXWIDGET_H
#define DSPINBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DSpinBox>

DWIDGET_USE_NAMESPACE

class DSpinBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSpinBoxWidget(QWidget *parent = nullptr);
    ~DSpinBoxWidget();

signals:

public slots:
};

#endif // DSPINBOXWIDGET_H
