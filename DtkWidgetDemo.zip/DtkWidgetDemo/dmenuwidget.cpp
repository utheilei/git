#include "dmenuwidget.h"

DmenuWidget::DmenuWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout();
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DMenu *pDMenu = new DMenu;

    QAction *newWindowAction(new QAction(tr("New window"), this));
    QAction *newTabAction(new QAction(tr("New tab"), this));
    QAction *openFileAction(new QAction(tr("Open file"), this));
    QAction *saveAction(new QAction(tr("Save"), this));
    QAction *saveAsAction(new QAction(tr("Save as"), this));
    QAction *printAction(new QAction(tr("Print"), this));
    QAction *switchThemeAction(new QAction(tr("Switch theme"), this));
    QAction *settingAction(new QAction(tr("Settings"), this));

    DMenu *pDMenuLevel2 = new DMenu(tr("一级菜单"));
    //pDMenuLevel2->setMinimumWidth(200);
    m_oneAction = new QAction(tr("选项1"), this);
    QAction *twoAction(new QAction(tr("选项2"), this));
    QAction *threeAction(new QAction(tr("选项3"), this));
    QAction *fourAction(new QAction(tr("选项4"), this));
    QAction *fiveAction(new QAction(tr("选项5"), this));
    QAction *sixAction(new QAction(tr("选项6"), this));
    pDMenuLevel2->addAction(m_oneAction);
    pDMenuLevel2->addAction(twoAction);
    pDMenuLevel2->addAction(threeAction);
    pDMenuLevel2->addAction(fourAction);
    pDMenuLevel2->addAction(fiveAction);
    pDMenuLevel2->addAction(sixAction);

    pDMenu->addAction(newWindowAction);
    pDMenu->addAction(newTabAction);
    pDMenu->addAction(openFileAction);
    pDMenu->addSeparator();
    pDMenu->addAction(saveAction);
    pDMenu->addAction(saveAsAction);
    pDMenu->addAction(printAction);
    //pDMenu->addAction(switchThemeAction);
    pDMenu->addSeparator();
    pDMenu->addAction(settingAction);
    pDMenu->addMenu(pDMenuLevel2);
    //pDMenu->show();

    connect(m_oneAction, &QAction::triggered, this, &DmenuWidget::slotActionTriggred);

    pHBoxLayout->addWidget(pDMenu);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DmenuWidget::~DmenuWidget()
{

}

void DmenuWidget::slotActionTriggred()
{
    m_oneAction->setIcon(QIcon(":/images/ok.svg"));
}
