#ifndef DTOASTWIDGET_H
#define DTOASTWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DPushButton>
#include <DToast>
#include <DMessageManager>
#include <DFloatingMessage>
#include <QFont>
#include <DFloatingWidget>

DWIDGET_USE_NAMESPACE

class DToastWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DToastWidget(QWidget *parent = nullptr);
    ~DToastWidget();

signals:

public slots:
    void slotDPuBtnClicked();
    void slotDPuBtn2Clicked();

private:
    DFloatingMessage *m_pDFloatMessage2;
    DFloatingMessage *m_pDFloatMessage3;
};

#endif // DTOASTWIDGET_H
