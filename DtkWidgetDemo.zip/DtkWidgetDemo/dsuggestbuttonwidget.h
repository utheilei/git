#ifndef DSUGGESTBUTTONWIDGET_H
#define DSUGGESTBUTTONWIDGET_H

#include <QWidget>
#include <DSuggestButton>
#include <DWarningButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DFontSizeManager>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DSuggestButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSuggestButtonWidget(QWidget *parent = nullptr);
    ~DSuggestButtonWidget();

signals:

public slots:
};

#endif // DSUGGESTBUTTON_H
