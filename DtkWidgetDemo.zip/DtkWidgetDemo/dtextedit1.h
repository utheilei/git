#ifndef DTEXTEDIT1_H
#define DTEXTEDIT1_H

#include <QWidget>
#include <DTextEdit>
#include <QPainter>
#include <QColor>
#include <QPaintEvent>
#include <QTextBlock>
#include <QPlainTextEdit>
#include "linenumberarea.h"

DWIDGET_USE_NAMESPACE

class DTextEdit1 : public DTextEdit //DTextEdit
{
    //Q_OBJECT
public:
    explicit DTextEdit1(DTextEdit *parent = nullptr);
    ~DTextEdit1();

    QWidget *lineNumberArea;

    void lineNumberAreaPaintEvent(QPaintEvent *event);
    int getFirstVisibleBlockId() const;
    int lineNumberAreaWidth();
    void updateLineNumber();
    int blockCount() const;

signals:

protected:
    void resizeEvent(QResizeEvent* event) override;

public slots:

private:
    int m_markStartLine = -1;
    QColor m_regionMarkerColor;
    QColor m_lineNumbersColor;
    int m_lineNumberPaddingX = 5;
};

#endif // DTEXTEDIT_H
