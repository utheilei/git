#include "dcrumbeditwidget.h"
#include <QDebug>

DCrumbEditWidget::DCrumbEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DCrumbEdit *pDCrumbEdit = new DCrumbEdit(this);
    pDCrumbEdit->makeTextFormat(DCrumbEdit::red);
    pDCrumbEdit->appendCrumb(tr("人物摄像"));
    pDCrumbEdit->appendCrumb(tr("儿童"));
    pDCrumbEdit->appendCrumb(tr("照片"));
    qDebug()<<pDCrumbEdit->crumbList()<<pDCrumbEdit->crumbReadOnly();
    pHBoxLayout->addWidget(pDCrumbEdit);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DCrumbEdit *pDCrumbEdit2 = new DCrumbEdit(this);
    DCrumbTextFormat *pDCrumbTextFormat = new DCrumbTextFormat();
    pHBoxLayout2->addWidget(pDCrumbEdit2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DCrumbEditWidget::~DCrumbEditWidget()
{

}
