#ifndef DERRORMESSAGEWIDGET_H
#define DERRORMESSAGEWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DPushButton>
#include <DErrorMessage>

DWIDGET_USE_NAMESPACE

class DErrorMessageWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DErrorMessageWidget(QWidget *parent = nullptr);
    ~DErrorMessageWidget();

signals:

public slots:
    void slotDPubBtnClicked();
};

#endif // DERRORMESSAGEWIDGET_H
