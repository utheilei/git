#include "printingwidget.h"

PrintingWidget::PrintingWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("打印"));
    connect(pDPusBtn, &DPushButton::clicked, this, [=] {
        QPrinter printer(QPrinter::HighResolution);
        QPrintPreviewDialog preview(&printer, this);

//        TextEdit *wrapper = currentWrapper()->textEditor();
//        const QString &filePath = wrapper->filepath;
//        const QString &fileDir = QFileInfo(filePath).dir().absolutePath();

//        if (fileDir == m_blankFileDir) {
//            printer.setOutputFileName(QString("%1/%2.pdf").arg(QDir::homePath(), m_tabbar->currentName()));
//        } else {
//            printer.setOutputFileName(QString("%1/%2.pdf").arg(fileDir, QFileInfo(filePath).baseName()));
//        }

        printer.setOutputFormat(QPrinter::PdfFormat);

//        connect(&preview, &QPrintPreviewDialog::paintRequested, this, [=] (QPrinter *printer) {
//            currentWrapper()->textEditor()->print(printer);
//        });

        preview.exec();
    });
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

PrintingWidget::~PrintingWidget()
{

}
