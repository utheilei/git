#ifndef DPROGRESSBARWIDGET_H
#define DPROGRESSBARWIDGET_H

#include <QWidget>
#include <DProgressBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTimer>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DProgressBarWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DProgressBarWidget(QWidget *parent = nullptr);
    ~DProgressBarWidget();

signals:

public slots:

private:
    DProgressBar *m_pDProgressBar;
    DProgressBar *m_pDProgressBar2;
    QTimer *m_pTimer;
    int m_iValue = 0;
};

#endif // DPROGRESSBARWIDGET_H
