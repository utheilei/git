#ifndef DFONTCOMBOBOXWIDGET_H
#define DFONTCOMBOBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DFontComboBox>
#include <DLabel>
#include <DApplicationHelper>
#include <DBackgroundGroup>

DWIDGET_USE_NAMESPACE

class DFontComboBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DFontComboBoxWidget(QWidget *parent = nullptr);
    ~DFontComboBoxWidget();

signals:

public slots:
    void slotSetFont(QFont font);

private:
    DLabel *m_pDLabel;
};

#endif // DFONTCOMBOBOXWIDGET_H
