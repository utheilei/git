#ifndef KEYSEQUENCEEDITWIDGET_H
#define KEYSEQUENCEEDITWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DKeySequenceEdit>
#include <QDebug>
#include <DMessageManager>
#include <DLabel>

DWIDGET_USE_NAMESPACE

class DKeySequenceEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DKeySequenceEditWidget(QWidget *parent = nullptr);
    ~DKeySequenceEditWidget();

signals:

public slots:
};

#endif // KEYSEQUENCEEDITWIDGET_H
