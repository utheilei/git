#include "dfontcomboboxwidget.h"

DFontComboBoxWidget::DFontComboBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(10);

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->addStretch();

    m_pDLabel = new DLabel("字体显示变化测试");
    m_pDLabel->setFixedSize(200, 30);
    DPalette paLaybel = DApplicationHelper::instance()->palette(m_pDLabel);
    QColor color = DApplicationHelper::instance()->palette(m_pDLabel).background().color();
    paLaybel.setColor(DPalette::Background, color);
    m_pDLabel->setPalette(paLaybel);
    pHBoxLayout1->addWidget(m_pDLabel);

    DFontComboBox *pDFontComboBox1 = new DFontComboBox();
    connect(pDFontComboBox1, &DFontComboBox::currentFontChanged, this, &DFontComboBoxWidget::slotSetFont);
    pDFontComboBox1->setFixedWidth(300);
    pHBoxLayout1->addWidget(pDFontComboBox1);
    pHBoxLayout1->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout1);

    this->setLayout(pMainVBoxLayout);
}

DFontComboBoxWidget::~DFontComboBoxWidget()
{

}

void DFontComboBoxWidget::slotSetFont(QFont font)
{
    m_pDLabel->setFont(font);
}
