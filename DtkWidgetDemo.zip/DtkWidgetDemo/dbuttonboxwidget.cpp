#include "dbuttonboxwidget.h"

#include <QStyle>

DButtonBoxWidget::DButtonBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(10);

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pDButtonBox = new DButtonBox();
    pDButtonBox->setFixedHeight(50);
    QList<DButtonBoxButton*> listBtnBox1;
    DButtonBoxButton *pBoxBtnLeft = new DButtonBoxButton(QStyle::SP_ArrowLeft, QStringLiteral("上一曲"));
    DButtonBoxButton *pBoxBtnRight = new DButtonBoxButton(QStyle::SP_ArrowRight, QStringLiteral("下一曲"));
    listBtnBox1.append(pBoxBtnLeft);
    listBtnBox1.append(pBoxBtnRight);
    pDButtonBox->setButtonList(listBtnBox1, true);
    pHBoxLayout->addWidget(pDButtonBox);
    pHBoxLayout->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout11 = new QHBoxLayout();
    pHBoxLayout11->addStretch();
    pDButtonBox = new DButtonBox();
    //pDButtonBox->setFixedHeight(40);
    QList<DButtonBoxButton*> listBtnBox11;
    DButtonBoxButton *pBoxBtnYear = new DButtonBoxButton(tr("年"));
    pBoxBtnYear->setMinimumWidth(60);
    DButtonBoxButton *pBoxBtnMonth = new DButtonBoxButton(tr("月"));
    pBoxBtnMonth->setMinimumWidth(60);
    DButtonBoxButton *pBoxBtnWeek = new DButtonBoxButton(tr("周"));
    pBoxBtnWeek->setMinimumWidth(60);
    DButtonBoxButton *pBoxBtnDay = new DButtonBoxButton(tr("日"));
    pBoxBtnDay->setMinimumWidth(60);
    listBtnBox11.append(pBoxBtnYear);
    listBtnBox11.append(pBoxBtnMonth);
    listBtnBox11.append(pBoxBtnWeek);
    listBtnBox11.append(pBoxBtnDay);
    pDButtonBox->setButtonList(listBtnBox11, true);
    pHBoxLayout11->addWidget(pDButtonBox);
    pHBoxLayout11->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout11);
    connect(pDButtonBox, &DButtonBox::buttonClicked, this, [=](QAbstractButton *pBtn) {
        if (pBtn == pBoxBtnYear) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning"), tr("年"));
        }
        else if (pBtn == pBoxBtnMonth) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning"), tr("月"));
        }
        else if (pBtn == pBoxBtnWeek) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning"), tr("周"));
        }
        else if (pBtn == pBoxBtnDay) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning"), tr("日"));
        }
    });

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->addStretch();
    DButtonBox *pDButtonBox1 = new DButtonBox();
    QList<DButtonBoxButton*> listBtnBox3;
    DButtonBoxButton *pBoxBtnUpdate = new DButtonBoxButton(QIcon(":/images/ok.svg"), QStringLiteral("检查更新"));
    DButtonBoxButton *pBoxBtnUpdateSet = new DButtonBoxButton(QIcon(":/images/warning.svg"), QStringLiteral("更新设置"));
    listBtnBox3.append(pBoxBtnUpdate);
    listBtnBox3.append(pBoxBtnUpdateSet);
    pDButtonBox1->setButtonList(listBtnBox3, true);
    pHBoxLayout1->addWidget(pDButtonBox1);
    pHBoxLayout1->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout1);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    m_pDButtonBox2 = new DButtonBox();
    m_pDButtonBox2->setOrientation(Qt::Vertical);
    m_pDButtonBox2->setFixedSize(50, 100);
    QList<DButtonBoxButton*> listBtnBox2;
    DButtonBoxButton *pBoxBtnUp = new DButtonBoxButton(QStyle::SP_ArrowUp, nullptr, this);
    DButtonBoxButton *pBoxBtnDown = new DButtonBoxButton(QStyle::SP_ArrowDown, nullptr, this);
    listBtnBox2.append(pBoxBtnUp);
    listBtnBox2.append(pBoxBtnDown);
    m_pDButtonBox2->setButtonList(listBtnBox2, true);
    pHBoxLayout2->addWidget(m_pDButtonBox2);
    pHBoxLayout2->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->addStretch();
    DPushButton *pDPushButton = new DPushButton(tr("应用"));
    pDPushButton->setFixedSize(100, 50);
    connect(pDPushButton, &DPushButton::clicked, this, &DButtonBoxWidget::slotDBtnClicked);
    pHBoxLayout3->addWidget(pDPushButton);
    pHBoxLayout3->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout3);

    this->setLayout(pMainVBoxLayout);
}

DButtonBoxWidget::~DButtonBoxWidget()
{

}

void DButtonBoxWidget::slotDBtnClicked()
{
    DButtonBox *pDButtonBox2 = new DButtonBox();
    pDButtonBox2->setFixedSize(100, 40);
    QList<DButtonBoxButton*> listBtnBox2;
    DButtonBoxButton *pBoxBtnUp = new DButtonBoxButton(QStyle::SP_ArrowLeft, nullptr, this);
    DButtonBoxButton *pBoxBtnDown = new DButtonBoxButton(QStyle::SP_ArrowRight, nullptr, this);
    listBtnBox2.append(pBoxBtnUp);
    listBtnBox2.append(pBoxBtnDown);
    pDButtonBox2->setButtonList(listBtnBox2, true);

    DMainWindow *mw = new DMainWindow();
    mw->titlebar()->setTitle("");
    mw->setMinimumSize(800, 400);
    mw->titlebar()->addWidget(pDButtonBox, Qt::AlignLeft);
    mw->titlebar()->setIcon(QIcon::fromTheme("dde-calendar"));
    mw->show();
}
