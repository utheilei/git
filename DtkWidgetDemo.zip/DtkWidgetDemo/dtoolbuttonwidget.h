#ifndef DTOOLBUTTONWIDGET_H
#define DTOOLBUTTONWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DToolButton>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DToolButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DToolButtonWidget(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DTOOLBUTTONWIDGET_H
