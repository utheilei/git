#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <DApplication>
#include <DMainWindow>
#include <QHBoxLayout>
#include <DListView>
#include <QStackedWidget>
#include <DTextEdit>
#include <DTitlebar>
#include <DSearchEdit>
#include <DButtonBox>
#include <DApplicationHelper>

#include <DStandardPaths>
#include <qsettingbackend.h>
#include <DSettingsDialog>

#include <QtDebug>

#include "slider.h"
#include "pushbutton.h"
#include "dwarningbutton.h"
#include "dsuggestbuttonwidget.h"
#include "diconbuttonwidget.h"
#include "dfloatingbuttonwidget.h"
#include "ddialwidget.h"
#include "dsrollbarwidget.h"
#include "dswitchbuttonwidget.h"
#include "dmessageboxwidget.h"
#include "dbuttonboxwidget.h"
#include "dcomboboxwidget.h"
#include "dfontcomboboxwidget.h"
#include "dradiobuttonwidget.h"
#include "dsearcheditwidget.h"
#include "dlineeditwidget.h"
#include "dipv4dlineeditwidget.h"
#include "dpasswordeditwidget.h"
#include "dfilechoosereditwidget.h"
#include "dspinboxwidget.h"
#include "dtexteditwidget.h"
#include "dcrumbeditwidget.h"
#include "dlcdnumberwidget.h"
#include "dtitlebarwidget.h"
#include "dtabbarwidget.h"
#include "dsizegripwidget.h"
#include "dtoastwidget.h"
#include "dstatusbarwidget.h"
#include "dverticallinewidget.h"
#include "dwaterprogresswidget.h"
#include "dmenuwidget.h"
#include "dtooltipwidget.h"
#include "dframewidget.h"
#include "dinputdialogwidget.h"
#include "ddialogwidget.h"
#include "ddialogbuttonboxwidget.h"
#include "dprogressdialogwidget.h"
#include "derrormessagewidget.h"
#include "dspinnerwidget.h"
#include "dbackgroundgroupwidget.h"
#include "dlistviewwidget.h"
#include "dcommandlinkbtuuonwidget.h"
#include "dprogressbarwidget.h"
#include "dgroupboxwidget.h"
#include "dtreewidgetwidget.h"
#include "animationwidget.h"
#include "readfilewidget.h"
#include "dfiledialogwidget.h"
#include "darrowrectanglewidget.h"
#include "printingwidget.h"
#include "dkeysequenceeditwidget.h"
#include "dtoolbuttonwidget.h"
#include "qplaintexteditwidget.h"

DWIDGET_USE_NAMESPACE

class MainWindow : public DMainWindow
{
public:
    MainWindow(DMainWindow *parent = 0);
    ~MainWindow();

private:
    QHBoxLayout *m_pHBoxLayout;
    DListView   *m_pDListView;
    QWidget *m_pCentralWidget;
    QStackedWidget *m_pStackedWidget;
    QHash<QString, QWidget*> m_has_ItemName_ItemWiget;

    SliderWidgt *m_pSliderWidgt;
    PushButtonWidget *m_pPushButtonWidget;
    WarningButtonWidget *m_pWarningButtonWidget;
    DSuggestButtonWidget *m_pDSuggestButtonWidget;
    DIconButtonWidget *m_pDIconButtonWidget;
    DFloatingButtonWidget *m_pDFloatingButtonWidget;
    DDialWidget *m_pDDialWidget;
    DSrollBarWidget *m_pDSrollBarWidget;
    DSwitchButtonWidget *m_pDSwitchButtonWidget;
    DMessageBoxWidget *m_pDMessageBoxWidget;
    DButtonBoxWidget *m_pDButtonBoxWidget;
    DComboBoxWidget *m_pDComboBoxWidget;
    DFontComboBoxWidget *m_pDFontComboBoxWidget;
    DRadioButtonWidget *m_pDRadioButtonWidget;
    DSearchEditWidget *m_pDSearchEditWidget;
    DLineEditWidget *m_pDLineEditWidget;
    DIpv4DlineEditWidget *m_pDIpv4DlineEditWidget;
    DPasswordEditWidget *m_pDPasswordEditWidget;
    DFileChooserEditWidget *m_pDFileChooserEditWidget;
    DSpinBoxWidget *m_pDSpinBoxWidget;
    DTextEditWidget *m_pDTextEditWidget;
    DCrumbEditWidget *m_pDCrumbEditWidget;
    DLCDNumberWidget *m_pDLCDNumberWidget;
    DTitlebarWidget *m_pDTitlebarWidget;
    DTabBarWidget *m_pDTabBarWidget;
    DSizegripWidget *m_pDSizegripWidget;
    DToastWidget *m_pDToastWidget;
    DStatusBarWidget *m_pDStatusBarWidget;
    DVerticalLineWidget *m_pDVerticalLineWidget;
    DWaterProgressWidget *m_pDWaterProgressWidget;
    DmenuWidget *m_pDmenuWidget;
    DToolTipWidget *m_pDToolTipWidget;
    DFrameWidget *m_pDFrameWidget;
    DInputDialogWidget *m_pDInputDialogWidget;
    DDialogWidget *m_pDDialogWidget;
    DDialogButtonBoxWidget *m_pDDialogButtonBoxWidget;
    DProgressDialogWidget *m_pDProgressDialogWidget;
    DErrorMessageWidget *m_pDErrorMessageWidget;
    DSpinnerWidget *m_pDSpinnerWidget;
    DBackgroundGroupWidget *m_pDBackgroundGroupWidget;
    DListViewWidget *m_pDListViewWidget;
    DCommandLinkButtonWidget *m_pDCommandLinkButtonWidget;
    DProgressBarWidget *m_pDProgressBarWidget;
    DGroupBoxWidget *m_pDGroupBoxWidget;
    DTreeWidgetWidget *m_pDTreeWidgetWidget;
    AnimationWidget *m_pAnimationWidget;
    ReadFileWidget *m_pReadFileWidget;
    DFileDialogWidget *m_pDFileDialogWidget;
    DArrowRectangleWidget *m_pDArrowRectangleWidget;
    PrintingWidget *m_pPrintingWidget;
    DKeySequenceEditWidget *m_pDKeySequenceEditWidget;
    DToolButtonWidget *m_pDToolButtonWidget;
    QPlainTextEditWidget *m_pQPlainTextEditWidget;

    QAction *m_oneAction;

    QString m_strConfDir;
    QString m_srConfPath;

public slots:
    void slotListViewItemClicked(const QModelIndex &index);
    void slotActionTriggred();

private:
    void settingsInit();
    void slotPopupSettingsDialog();
};

#endif // MAINWINDOW_H
