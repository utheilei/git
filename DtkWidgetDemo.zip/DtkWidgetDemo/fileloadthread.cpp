/*
 * Copyright (C) 2017 ~ 2018 Deepin Technology Co., Ltd.
 *
 * Author:     rekols <rekols@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fileloadthread.h"
//#include "utils.h"

#include <QCoreApplication>
#include <QPlainTextEdit>
#include <QTextDocument>
#include <QTextStream>
#include <QFile>
#include <QDebug>

FileLoadThread::FileLoadThread(const QString &filepath, QObject *parent)
    : QThread(parent),
      m_filePath(filepath)
{

}

FileLoadThread::~FileLoadThread()
{
}

void FileLoadThread::run()
{
    QFile file(m_filePath);
    QFileInfo fileInfo(m_filePath);
    QString strFileName = fileInfo.fileName();
    qDebug() << "=========== strFileName:" << strFileName;
    QPixmap pixmap;


    //---------- 方法1 QFile::copy　本地能加载62M大小的4.5M图片可以加载出来，5.5M以上图片加载有问题 ------------
    bool ret = QFile::copy(m_filePath, strFileName);
    qDebug() << "=========== ret:" << ret;
    qDebug() << "=========== fileInfo.size():" << fileInfo.size();
    if (ret == true) {
        QFile fileT(strFileName);
        if (fileT.exists()) {
            pixmap.load(strFileName);

            emit sigLoadPixmapFinished(pixmap);

            fileT.remove();
        }
    }


    //---------- 方法2 QIODevice::ReadOnly 4.5M图片可以加载出来，5.5M以上图片加载有问题------------
//    if (file.open(QIODevice::ReadOnly)) {
//        // reads all remaining data from the file.
//        QByteArray byteArray = file.readAll();
//        //tImg.fromData(&byteArray, format.toLatin1());
//        QImage tImg = QImage::fromData(byteArray, nullptr);
//        //tImg.save("test_clicked.jpg", "JPG", 50);
//        pixmap = QPixmap::fromImage(tImg);

//        emit sigLoadPixmapFinished(pixmap);

//        file.close();
//    }


//        QTextStream stream(&fileContent);
//        stream.setCodec("UTF-8");

//        QString content = stream.readAll();
//        qDebug() << "In thread content:" << content;
}
