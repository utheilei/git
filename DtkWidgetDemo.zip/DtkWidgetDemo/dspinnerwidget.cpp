#include "dspinnerwidget.h"

DSpinnerWidget::DSpinnerWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(70);

    DSpinner *pDSpinner = new DSpinner();
    pDSpinner->setMinimumSize(20, 20);
    pHBoxLayout->addWidget(pDSpinner);
    DSpinner *pDSpinner2 = new DSpinner();
    pDSpinner2->setMinimumSize(50, 50);
    pHBoxLayout->addWidget(pDSpinner2);
    DSpinner *pDSpinner3 = new DSpinner();
    pDSpinner3->setMinimumSize(100, 100);
    pHBoxLayout->addWidget(pDSpinner3);
    DSpinner *pDSpinner4 = new DSpinner();
    pDSpinner4->setBackgroundColor(QColor("#002200"));
    pDSpinner4->setMinimumSize(120, 120);
    pHBoxLayout->addWidget(pDSpinner4);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    m_pDPusBtn = new DPushButton(tr("开始转动"));
    m_pDPusBtn->setCheckable(true);
    connect(m_pDPusBtn, &DPushButton::clicked, this, [=]
    {
        if(m_pDPusBtn->isChecked() == true) {
            pDSpinner->start();
            pDSpinner2->start();
            pDSpinner3->start();
            pDSpinner4->start();
            m_pDPusBtn->setText(tr("停止转动"));
        }
        else {
            pDSpinner->stop();
            pDSpinner2->stop();
            pDSpinner3->stop();
            pDSpinner4->stop();
            m_pDPusBtn->setText(tr("开始转动"));
        }
    });
    pHBoxLayout2->addWidget(m_pDPusBtn);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DSpinnerWidget::~DSpinnerWidget()
{

}

void DSpinnerWidget::slotDPusBtnClicked()
{

}
