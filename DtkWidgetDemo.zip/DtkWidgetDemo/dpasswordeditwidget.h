#ifndef DPASSWORDEDITWIDGET_H
#define DPASSWORDEDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPasswordEdit>
#include <DPushButton>
#include <DLabel>
#include <DLineEdit>
#include <QGridLayout>
#include <DLabel>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DPasswordEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DPasswordEditWidget(QWidget *parent = nullptr);
    ~DPasswordEditWidget();

signals:

public slots:
    void slotDpushBtnClicked();

private:
    DPasswordEdit *m_pDPasswordEdit;
    DLineEdit *m_pDLineEdit;
};

#endif // DPASSWORDEDITWIDGET_H
