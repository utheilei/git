#ifndef DSPINNERWIDGET_H
#define DSPINNERWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPushButton>
#include <DSpinner>

DWIDGET_USE_NAMESPACE

class DSpinnerWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSpinnerWidget(QWidget *parent = nullptr);
    ~DSpinnerWidget();

signals:

public slots:
    void slotDPusBtnClicked();

private:
    DPushButton *m_pDPusBtn;
};

#endif // DSPINNERWIDGET_H
