#ifndef DARROWRECTANGLEWIDGET_H
#define DARROWRECTANGLEWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DArrowRectangle>
#include <DPushButton>
#include <QAction>
#include <DListView>
#include <DSlider>

DWIDGET_USE_NAMESPACE

class DArrowRectangleWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DArrowRectangleWidget(QWidget *parent = nullptr);
    ~DArrowRectangleWidget();

signals:

public slots:

private:
    DListView *m_pDListView;
};

#endif // DARROWRECTANGLEWIDGET_H
