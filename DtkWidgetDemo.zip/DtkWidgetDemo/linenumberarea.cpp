#include "linenumberarea.h"
#include "dtextedit1.h"

LineNumberArea::LineNumberArea(DTextEdit1 *textEdit)
{
    m_textEdit = textEdit;
}

LineNumberArea::~LineNumberArea()
{

}

void LineNumberArea::paintEvent(QPaintEvent *e)
{
    m_textEdit->lineNumberAreaPaintEvent(e);
}

QSize LineNumberArea::sizeHint() const
{
    return QSize(m_textEdit->lineNumberAreaWidth(), 0);
}
