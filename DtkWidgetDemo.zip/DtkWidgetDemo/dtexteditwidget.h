#ifndef DTEXTEDITWIDGET_H
#define DTEXTEDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVariantHash>
#include <DTextEdit>
#include "dtextedit1.h"
#include <DPushButton>
#include <QFileDialog>
#include "fileloadthread.h"

DWIDGET_USE_NAMESPACE

class DTextEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DTextEditWidget(QWidget *parent = nullptr);
    ~DTextEditWidget();

signals:

public slots:
    void slotDPushBtnClicked();
    void handleFileLoadFinished(const QByteArray &encode, const QString &content);

private:
    DTextEdit1 *m_pDTextEdit;
};

#endif // DTEXTEDITWIDGET_H
