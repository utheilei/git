#include "dmessageboxwidget.h"

DMessageBoxWidget::DMessageBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(30);

    DPushButton *pDPushButton = new DPushButton("显示 DMessageBox");
    connect(pDPushButton, &DPushButton::clicked, this, &DMessageBoxWidget::slotShowBtnClicked);
    pHBoxLayout->addWidget(pDPushButton);

    m_pDMessageBox1 = new DMessageBox(DMessageBox::Icon::Information,
                                                 tr("警告"), tr("是否要删除该文件？"),
                                                 DMessageBox::StandardButton::Ok
                                               | DMessageBox::StandardButton::Cancel, this);
    //pHBoxLayout->addWidget(m_pDMessageBox1);

    m_pDMessageBox2 = new DMessageBox(DMessageBox::Icon::Information,
                                                 tr("警告"), tr("是否要删除该文件？"),
                                                 DMessageBox::StandardButton::Ok
                                               | DMessageBox::StandardButton::Cancel);
    pHBoxLayout->addWidget(m_pDMessageBox2);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}

DMessageBoxWidget::~DMessageBoxWidget()
{

}

void DMessageBoxWidget::slotShowBtnClicked()
{
    m_pDMessageBox1->show();
}
