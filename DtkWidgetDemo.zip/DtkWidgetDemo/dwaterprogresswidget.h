#ifndef DWATERPROGRESSWIDGET_H
#define DWATERPROGRESSWIDGET_H

#include <QWidget>
#include <DWaterProgress>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTimer>
#include <DPushButton>
#include <QDebug>

DWIDGET_USE_NAMESPACE

class DWaterProgressWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DWaterProgressWidget(QWidget *parent = nullptr);

signals:

public slots:
    void slotDPuBtnClicked();
    void slotTimerOut();

private:
    QTimer *m_ptimer;
    DWaterProgress *m_pDWaterProgress;
    int m_valus = 0;
    DPushButton *m_pDPushButton;
};

#endif // DWATERPROGRESSWIDGET_H
