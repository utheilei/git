#ifndef WARNINGBUTTON_H
#define WARNINGBUTTON_H

#include <QWidget>
#include <DWarningButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStyleOptionButton>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class WarningButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit WarningButtonWidget(QWidget *parent = nullptr);
    ~WarningButtonWidget();

signals:

public slots:
};

#endif // WARNINGBUTTON_H
