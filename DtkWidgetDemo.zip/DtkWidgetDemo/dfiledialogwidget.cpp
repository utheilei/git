 #include "dfiledialogwidget.h"

DFileDialogWidget::DFileDialogWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("打开文件"));
    connect(pDPusBtn, &DPushButton::clicked, this, [=] {
        DFileDialog *pDFileDialog = new DFileDialog();
        pDFileDialog->setAcceptMode(QFileDialog::AcceptOpen); //文件对话框为打开文件类型
        pDFileDialog->setFileMode(QFileDialog::ExistingFiles); //可同时选择打开多个文件
        pDFileDialog->show();
        pDFileDialog->exec();

        QStringList strlistSelectedName = pDFileDialog->selectedFiles();
        for (QString strSelectFile : strlistSelectedName) {
            QFileInfo fileInfo(strSelectFile);
            DMessageManager::instance()->sendMessage(this, QIcon(":images/ok.svg"), QString("打开文件 %1").arg(fileInfo.fileName()));
        }
    });
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDPusBtn2 = new DPushButton(tr("文件另存为"));
    DFileDialog::DComboBoxOptions ComboBoxOptions;
    ComboBoxOptions.editable = true;
    ComboBoxOptions.data << "UTF-8" << "Big5" << "UTF-16" << "GBK";
    ComboBoxOptions.defaultValue = "UTF-8";
    connect(pDPusBtn2, &DPushButton::clicked, this, [=] {
        DFileDialog *pDFileDialog = new DFileDialog();
        pDFileDialog->setAcceptMode(QFileDialog::AcceptSave); //文件对话框为保存类型
        pDFileDialog->addComboBox(tr("编码"), ComboBoxOptions);
        pDFileDialog->show();

        int mode = pDFileDialog->exec();
        if (mode == QDialog::Accepted) {
            QString strCode = pDFileDialog->getComboBoxValue(tr("编码"));
            QString strSaveFileName = pDFileDialog->selectedFiles().value(0);
            QFileInfo fileInfo(strSaveFileName);
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), QString("文件%1保存为%2格式").arg(fileInfo.fileName()).arg(strCode));
        }
    });
    pHBoxLayout2->addWidget(pDPusBtn2);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DFileDialogWidget::~DFileDialogWidget()
{

}
