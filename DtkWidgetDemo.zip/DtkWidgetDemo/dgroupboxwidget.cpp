#include "dgroupboxwidget.h"

DGroupBoxWidget::DGroupBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(50);
    pHBoxLayout->addStretch();

    //========列表1
    DGroupBox *pDGroupBox = new DGroupBox(tr("列表1"));
    QVBoxLayout *pVBoxLayoutCheck = new QVBoxLayout();
    DCheckBox *pDCheckBox1 = new DCheckBox(tr("xuanxiang 1"));
    pDCheckBox1->setChecked(true);
    DCheckBox *pDCheckBox2 = new DCheckBox(tr("xuan xiang 2"));
    DCheckBox *pDCheckBox3 = new DCheckBox(tr("xuan xiang 3"));
    DCheckBox *pDCheckBox4 = new DCheckBox(tr("xuan xiang 4"));
    DCheckBox *pDCheckBox5 = new DCheckBox(tr("xuan xiang 5"));
    pVBoxLayoutCheck->addWidget(pDCheckBox1);
    pVBoxLayoutCheck->addWidget(pDCheckBox2);
    pVBoxLayoutCheck->addWidget(pDCheckBox3);
    pVBoxLayoutCheck->addWidget(pDCheckBox4);
    pVBoxLayoutCheck->addWidget(pDCheckBox5);
    pDGroupBox->setLayout(pVBoxLayoutCheck);
    pHBoxLayout->addWidget(pDGroupBox);

    //========列表2
    DGroupBox *pDGroupBox2 = new DGroupBox(tr("列表2"));
    //pDGroupBox2->setFlat(true);
    QVBoxLayout *pListviewVBoxLayout = new QVBoxLayout();
    pListviewVBoxLayout->setSpacing(20);

    DListWidget *pDListWidget = new DListWidget();

    QListWidgetItem *QListWidgetItem1 = new QListWidgetItem();
    pDListWidget->addItem(QListWidgetItem1);
    QWidget *pWidget1 = new QWidget();
    QHBoxLayout *pHBLayout1 = new QHBoxLayout();
    pHBLayout1->setSpacing(10);
    DIconButton *pDIconButton1 = new DIconButton(nullptr);
    pDIconButton1->setIcon(QIcon::fromTheme("deepin-editor"));
    pDIconButton1->setIconSize(QSize(30, 30));
    pDIconButton1->setFlat(true);
    pHBLayout1->addWidget(pDIconButton1);
    DLabel *pDLabel = new DLabel(tr("谷歌浏览器"));
    pHBLayout1->addWidget(pDLabel);
    pHBLayout1->addStretch();
    DIconButton *pDIconButton11 = new DIconButton(nullptr);
    pDIconButton11->setIcon(QIcon(":/images/ok.svg"));
    pDIconButton11->setIconSize(QSize(30, 30));
    pDIconButton11->setFlat(true);
    pHBLayout1->addWidget(pDIconButton11);
    pWidget1->setLayout(pHBLayout1);
    pDListWidget->setItemWidget(QListWidgetItem1, pWidget1);

    QListWidgetItem *QListWidgetItem2 = new QListWidgetItem();
    pDListWidget->addItem(QListWidgetItem2);
    QWidget *pWidget2 = new QWidget();
    QHBoxLayout *pHBLayout2 = new QHBoxLayout();
    pHBLayout2->setSpacing(10);
    DIconButton *pDIconButton2 = new DIconButton(nullptr);
    pDIconButton2->setIcon(QIcon::fromTheme("deepin-editor"));
    pDIconButton2->setIconSize(QSize(30, 30));
    pDIconButton2->setFlat(true);
    pHBLayout2->addWidget(pDIconButton2);
    DLabel *pDLabel2 = new DLabel(tr("火狐浏览器"));
    pHBLayout2->addWidget(pDLabel2);
    pHBLayout2->addStretch();
    DIconButton *pDIconButton22 = new DIconButton(nullptr);
    pDIconButton22->setIcon(QIcon(":/images/ok.svg"));
    pDIconButton22->setIconSize(QSize(30, 30));
    pDIconButton22->setFlat(true);
    pHBLayout2->addWidget(pDIconButton22);
    pWidget2->setLayout(pHBLayout2);
    pDListWidget->setItemWidget(QListWidgetItem2, pWidget2);

    pListviewVBoxLayout->addWidget(pDListWidget);
    pDGroupBox2->setLayout(pListviewVBoxLayout);
    pHBoxLayout->addWidget(pDGroupBox2);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DGroupBoxWidget::~DGroupBoxWidget()
{

}
