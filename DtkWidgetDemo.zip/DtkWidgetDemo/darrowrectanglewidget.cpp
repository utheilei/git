#include "darrowrectanglewidget.h"

DArrowRectangleWidget::DArrowRectangleWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DArrowRectangle *pDArrowRectangle = new DArrowRectangle(DArrowRectangle::ArrowBottom, DArrowRectangle::FloatWidget);
    //pDArrowRectangle->setHeight(100);
    //pDArrowRectangle->setContent(new DPushButton(tr("按钮1")));
    //pDArrowRectangle->setContent(new DPushButton(tr("按钮2")));
    //QAction *pAction1(new QAction(tr("第一项"), this));
    //QAction *newTabAction(new QAction(tr("New tab"), this));
    //pDArrowRectangle->addAction(pAction1);
    m_pDListView = new DListView();
    QStandardItemModel *pItemModel = new QStandardItemModel();
    DStandardItem *pItem1 = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), tr("指纹1"));
    pItemModel->appendRow(pItem1);
    DStandardItem *pItem2 = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), tr("指纹2"));
    pItemModel->appendRow(pItem2);
    DStandardItem *pItem3 = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), tr("指纹3"));
    pItemModel->appendRow(pItem3);
    m_pDListView->setModel(pItemModel);
    pDArrowRectangle->setContent(m_pDListView);

    DArrowRectangle *pDArrowRectangle2 = new DArrowRectangle(DArrowRectangle::ArrowBottom, DArrowRectangle::FloatWidget);
    DSlider *pDSlider = new DSlider(Qt::Vertical);
    pDSlider->setMinimumHeight(200);
    pDArrowRectangle2->setMargin(10);
    pDArrowRectangle2->setContent(pDSlider);

    pHBoxLayout->addWidget(pDArrowRectangle);
    pHBoxLayout->addWidget(pDArrowRectangle2);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DArrowRectangleWidget::~DArrowRectangleWidget()
{

}
