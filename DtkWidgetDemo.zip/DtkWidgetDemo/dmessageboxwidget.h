#ifndef DMESSAGEBOXWIDGET_H
#define DMESSAGEBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DMessageBox>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DMessageBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DMessageBoxWidget(QWidget *parent = nullptr);
    ~DMessageBoxWidget();

signals:

public slots:
    void slotShowBtnClicked();

private:
    DMessageBox *m_pDMessageBox1;
    DMessageBox *m_pDMessageBox2;
};

#endif // DMESSAGEBOXWIDGET_H
