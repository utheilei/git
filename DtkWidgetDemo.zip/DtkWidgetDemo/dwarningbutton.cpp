#include "dwarningbutton.h"

WarningButtonWidget::WarningButtonWidget(QWidget *parent)
    : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();

    //警告按钮
    DWarningButton *pDWarningButton1 = new DWarningButton();
    connect(pDWarningButton1, &DWarningButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    pHBoxLayout->addWidget(pDWarningButton1);
    pDWarningButton1->setText(tr("删除"));
    pDWarningButton1->setMinimumWidth(100);

    DWarningButton *pDWarningButton2 = new DWarningButton();
    pDWarningButton2->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDWarningButton2);
    pDWarningButton2->setDisabled(true);
    pDWarningButton2->setText(tr("警告按钮"));

    DWarningButton *pDWarningButton3 = new DWarningButton();
    pDWarningButton3->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDWarningButton3);
    //setFocusProxy(pDPushButton3);
    pDWarningButton3->setFocusPolicy(Qt::StrongFocus);
    pDWarningButton3->setText(tr("警告按钮"));

    DWarningButton *pDWarningButton4 = new DWarningButton();
    pHBoxLayout->addWidget(pDWarningButton4);
    pDWarningButton4->setText(tr("warning button"));

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}

WarningButtonWidget::~WarningButtonWidget()
{

}
