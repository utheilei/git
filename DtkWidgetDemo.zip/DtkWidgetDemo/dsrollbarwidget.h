#ifndef DSROLLBARWIDGET_H
#define DSROLLBARWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DScrollBar>
#include <QLabel>

DWIDGET_USE_NAMESPACE

class DSrollBarWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSrollBarWidget(QWidget *parent = nullptr);

signals:

public slots:

private:
    QLabel *m_pLabel;
};

#endif // DSROLLBARWIDGET_H
