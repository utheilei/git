#include "dtabbarwidget.h"

DTabBarWidget::DTabBarWidget(QWidget *parent) :
                            QWidget(parent),
                            m_pMainWindow (new DMainWindow())
{
    m_pDTabBar = new DTabBar();
    connect(m_pDTabBar, &DTabBar::tabAddRequested, this, &DTabBarWidget::slotTabAddRequested);
    connect(m_pDTabBar, &DTabBar::tabCloseRequested, this, &DTabBarWidget::slotTabCloseRequested);
    m_pDTabBar->setTabsClosable(true);
    //m_pDTabBar->setBackgroundRole(QPalette::Base);
    //m_pDTabBar->setAutoFillBackground(true);
    m_pMainWindow->titlebar()->addWidget(m_pDTabBar, Qt::AlignLeft);
    m_pMainWindow->setMinimumSize(800, 400);
    m_pMainWindow->titlebar()->setIcon(QIcon(":/images/logo_24.svg"));
    m_pMainWindow->titlebar()->setTitle("");

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DPushButton *pDPushButton = new DPushButton(QStringLiteral("DTabBar应用"));
    pDPushButton->setFixedWidth(150);
    connect(pDPushButton, &DPushButton::clicked, this, &DTabBarWidget::slotDPuBtnClicked);
    pHBoxLayout->addWidget(pDPushButton);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

void DTabBarWidget::slotDPuBtnClicked()
{
    m_pMainWindow->show();
}

void DTabBarWidget::slotTabAddRequested()
{
    qDebug() << "In function [" << __FUNCTION__ << "].";
    m_pDTabBar->addTab(QStringLiteral("空白标签"));
}

void DTabBarWidget::slotTabCloseRequested(int index)
{
    qDebug() << "In function [" << __FUNCTION__ << "]. index:" << index;
    m_pDTabBar->removeTab(index);
    //DTabBar::removeTab(index);
}
