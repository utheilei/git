#include "dprogressbarwidget.h"

DProgressBarWidget::DProgressBarWidget(QWidget *parent) : QWidget(parent)
{
    m_pTimer = new QTimer();
    m_pTimer->setInterval(100);
    connect(m_pTimer, &QTimer::timeout, this, [=] {
        m_iValue += 1;
        if (m_iValue == 100) {
            m_iValue = 0;
        }
        m_pDProgressBar->setValue(m_iValue);
        m_pDProgressBar->setFormat(QString("已下载%1%").arg(m_iValue));
        m_pDProgressBar2->setValue(m_iValue);
        update();
    });

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->addStretch();
    pMainLayout->setSpacing(20);

    QHBoxLayout *pHBoxLatout1 = new QHBoxLayout();
    pHBoxLatout1->addStretch();
    m_pDProgressBar = new DProgressBar();
    m_pDProgressBar->setMinimumWidth(400);
    //m_pDProgressBar->setAlignment(Qt::AlignCenter);
    m_pDProgressBar->setRange(0, 100);
    pHBoxLatout1->addWidget(m_pDProgressBar);
    pHBoxLatout1->addStretch();
    pMainLayout->addLayout(pHBoxLatout1);

    QHBoxLayout *pHBoxLatout11 = new QHBoxLayout();
    pHBoxLatout11->addStretch();
    m_pDProgressBar2 = new DProgressBar();
    m_pDProgressBar2->setMaximumHeight(8);
    m_pDProgressBar2->setMinimumWidth(400);
    //m_pDProgressBar2->setAlignment(Qt::AlignCenter);
    m_pDProgressBar2->setTextVisible(false);
    m_pDProgressBar2->setRange(0, 100);
    pHBoxLatout11->addWidget(m_pDProgressBar2);
    pHBoxLatout11->addStretch();
    pMainLayout->addLayout(pHBoxLatout11);

    QHBoxLayout *pHBoxLatout2 = new QHBoxLayout();
    pHBoxLatout2->addStretch();
    DPushButton *pDPushButton = new DPushButton(tr("开始加载"));
    pDPushButton->setCheckable(true);
    connect(pDPushButton, &DPushButton::clicked, this, [=] {
        if (pDPushButton->isChecked() == true) {
            m_pTimer->start();
            pDPushButton->setText(tr("停止加载"));
        }
        else {
            m_pTimer->stop();
            pDPushButton->setText(tr("开始加载"));
        }
    });
    pHBoxLatout2->addWidget(pDPushButton);
    pHBoxLatout2->addStretch();
    pMainLayout->addLayout(pHBoxLatout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DProgressBarWidget::~DProgressBarWidget()
{

}
