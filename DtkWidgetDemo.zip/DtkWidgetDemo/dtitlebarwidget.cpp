#include "dtitlebarwidget.h"

DTitlebarWidget::DTitlebarWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DPushButton *pDPushButtonLogo = new DPushButton(QStringLiteral("DTitlebar插入logo"));
    pDPushButtonLogo->setFixedWidth(200);
    connect(pDPushButtonLogo, &DPushButton::clicked, this, &DTitlebarWidget::slotDPuBtnLogoClicked);
    pHBoxLayout->addWidget(pDPushButtonLogo);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DPushButton *pDPusBtnSearEdit = new DPushButton(QStringLiteral("DTitlebar插入DSearEdit"));
    pDPusBtnSearEdit->setFixedWidth(200);
    connect(pDPusBtnSearEdit, &DPushButton::clicked, this, &DTitlebarWidget::slotDPuBtnSearEditClicked);
    pHBoxLayout2->addWidget(pDPusBtnSearEdit);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->setSpacing(0);
    pHBoxLayout3->addStretch();
    DPushButton *pDPusBtnButtonBox = new DPushButton(QStringLiteral("DTitlebar插入ButtonBox"));
    pDPusBtnButtonBox->setFixedWidth(200);
    connect(pDPusBtnButtonBox, &DPushButton::clicked, this, &DTitlebarWidget::slotDPuBtnButtonBoxClicked);
    pHBoxLayout3->addWidget(pDPusBtnButtonBox);
    pHBoxLayout3->addStretch();
    pMainLayout->addLayout(pHBoxLayout3);

    QHBoxLayout *pHBoxLayout4 = new QHBoxLayout();
    pHBoxLayout4->setSpacing(0);
    pHBoxLayout4->addStretch();
    DPushButton *pDPusBtnTabBar = new DPushButton(QStringLiteral("DTitlebar插入TabBar"));
    pDPusBtnTabBar->setFixedWidth(200);
    connect(pDPusBtnTabBar, &DPushButton::clicked, this, &DTitlebarWidget::slotDPuBtnTabBarClicked);
    pHBoxLayout4->addWidget(pDPusBtnTabBar);
    pHBoxLayout4->addStretch();
    pMainLayout->addLayout(pHBoxLayout4);

    QHBoxLayout *pHBoxLayout5 = new QHBoxLayout();
    pHBoxLayout5->setSpacing(0);
    pHBoxLayout5->addStretch();
    DPushButton *pDPusBtnIconBtn = new DPushButton(tr("左 中 右"));
    pDPusBtnIconBtn->setFixedWidth(200);
    connect(pDPusBtnIconBtn, &DPushButton::clicked, this, &DTitlebarWidget::slotDPuBtnIconBtnClicked);
    pHBoxLayout5->addWidget(pDPusBtnIconBtn);
    pHBoxLayout5->addStretch();
    pMainLayout->addLayout(pHBoxLayout5);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DTitlebarWidget::~DTitlebarWidget()
{

}

void DTitlebarWidget::slotDPuBtnLogoClicked()
{
    DMainWindow *w = new DMainWindow(this);
    w->setMinimumSize(800, 400);
    w->titlebar()->setIcon(QIcon(":/images/logo_24.svg"));
    w->show();
}

void DTitlebarWidget::slotDPuBtnSearEditClicked()
{
    DMainWindow *w = new DMainWindow();
    w->setMinimumSize(800, 400);
    w->titlebar()->addWidget(new DSearchEdit);
    w->show();
}

void DTitlebarWidget::slotDPuBtnButtonBoxClicked()
{
    DButtonBox *pDButtonBox = new DButtonBox();
    QList<DButtonBoxButton *> listButtonBox;
    DButtonBoxButton *pDButtonBoxBtn1 = new DButtonBoxButton(QStyle::SP_ArrowLeft, QStringLiteral("上一曲"));
    DButtonBoxButton *pDButtonBoxBtn2 = new DButtonBoxButton(QStyle::SP_ArrowRight, QStringLiteral("下一曲"));
    listButtonBox.append(pDButtonBoxBtn1);
    listButtonBox.append(pDButtonBoxBtn2);
    pDButtonBox->setButtonList(listButtonBox, false);

    DMainWindow *w = new DMainWindow();
    w->setMinimumSize(800, 400);
    w->titlebar()->addWidget(pDButtonBox);
    w->show();
}

void DTitlebarWidget::slotDPuBtnTabBarClicked()
{
    DMainWindow *w = new DMainWindow();
    w->setMinimumSize(800, 400);
   // w->setFixedSize(800,400);
    DTabBar *pTabBar = new DTabBar();

    pTabBar->addTab(QStringLiteral("新建tab1"));
    pTabBar->addTab(QStringLiteral("新建tab2"));
    pTabBar->addTab(QStringLiteral("新建tab3"));
    //pTabBar->insertTab(1, QStringLiteral("新建1"));
    //pTabBar->insertTab(2, QStringLiteral("新建2"));
    w->titlebar()->addWidget(pTabBar);
    w->show();
}

void DTitlebarWidget::slotDPuBtnIconBtnClicked()
{
    DIconButton *pDIconBtn = new DIconButton(DStyle::SP_IncreaseElement);
    DMainWindow *w = new DMainWindow();
    w->setMinimumSize(800, 400);
    w->titlebar()->setIcon(QIcon::fromTheme("deepin-editor"));
    w->titlebar()->addWidget(pDIconBtn, Qt::AlignLeft);

    DIconButton *pDIconBtn2 = new DIconButton(DStyle::SP_IncreaseElement);
    w->titlebar()->addWidget(pDIconBtn2, Qt::AlignCenter);

    DIconButton *pDIconBtn3 = new DIconButton(DStyle::SP_IncreaseElement);
    w->titlebar()->addWidget(pDIconBtn3, Qt::AlignRight);

    w->show();
}
