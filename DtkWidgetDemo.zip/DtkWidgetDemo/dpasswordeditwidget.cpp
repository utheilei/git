#include "dpasswordeditwidget.h"

DPasswordEditWidget::DPasswordEditWidget(QWidget *parent) : QWidget(parent)
{
//    DWidget *pDWidget = new DWidget();
//    pDWidget->setMinimumSize(300, 100);
//    QGridLayout *pGridLayout = new QGridLayout();
//    DLabel *pDLabel1 = new DLabel(tr("yonghuming:"));
//    DLabel *pDLabel2 = new DLabel(tr("mima:"));
//    DPushButton *pDPushButton1 = new DPushButton(tr("按钮1"));
//    pDPushButton1->setMinimumWidth(180);
//    DPushButton *pDPushButton2 = new DPushButton(tr("按钮2"));
//    pDPushButton2->setMinimumWidth(180);
//    pGridLayout->addWidget(pDLabel1, 0, 0);
//    pGridLayout->addWidget(pDLabel2, 1, 0);
//    pGridLayout->addWidget(pDPushButton1, 0, 1);
//    pGridLayout->addWidget(pDPushButton2, 1, 1);

//    pDWidget->setLayout(pGridLayout);

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->setSpacing(5);
    pHBoxLayout3->addStretch();
    DLabel *pDLabel = new DLabel(tr("用户："));
    pHBoxLayout3->addWidget(pDLabel);
    m_pDLineEdit= new DLineEdit();
    pHBoxLayout3->addWidget(m_pDLineEdit);
    pHBoxLayout3->addStretch();
    pMainLayout->addLayout(pHBoxLayout3);

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->setSpacing(5);
    pHBoxLayout1->addStretch();
    DLabel *pDLabel2 = new DLabel(QStringLiteral("密码："));
    pHBoxLayout1->addWidget(pDLabel2);
    m_pDPasswordEdit = new DPasswordEdit();
    m_pDPasswordEdit->setEchoButtonIsVisible(true);
    m_pDPasswordEdit->setEchoMode(QLineEdit::Normal);
    pHBoxLayout1->addWidget(m_pDPasswordEdit);
    pHBoxLayout1->addStretch();
    pMainLayout->addLayout(pHBoxLayout1);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDpushBtn2 = new DPushButton(QStringLiteral("登录"));
    //connect(pDpushBtn2, &DPushButton::clicked, this, [=] {
    //   pDWidget->show();
    //});
    connect(pDpushBtn2, &DPushButton::clicked, this, &DPasswordEditWidget::slotDpushBtnClicked);
    pDpushBtn2->setFixedWidth(70);
    pHBoxLayout2->addWidget(pDpushBtn2);
    DPushButton *pDpushBtn = new DPushButton(QStringLiteral("取消"));
    pDpushBtn->setFixedWidth(70);
    pHBoxLayout2->addWidget(pDpushBtn);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DPasswordEditWidget::~DPasswordEditWidget()
{

}

void DPasswordEditWidget::slotDpushBtnClicked()
{
    if(m_pDLineEdit->text() == "")
    {
        m_pDLineEdit->showAlertMessage(QStringLiteral("不能为空"));
    }

    if(m_pDPasswordEdit->text() == "")
    {
        m_pDPasswordEdit->showAlertMessage(QStringLiteral("不能为空"));
    }
    else if(m_pDPasswordEdit->text() != "123")
    {
        m_pDPasswordEdit->showAlertMessage(QStringLiteral("密码错误"));
    }
}
