#ifndef DTABBARWIDGET_H
#define DTABBARWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPushButton>
#include <DTabBar>
#include <DMainWindow>
#include <DTitlebar>
#include <QDebug>

DWIDGET_USE_NAMESPACE

class DTabBarWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DTabBarWidget(QWidget *parent = nullptr);

signals:

public slots:
    void slotDPuBtnClicked();
    void slotTabAddRequested();
    void slotTabCloseRequested(int index);

private:
    DMainWindow *m_pMainWindow;
    DTabBar *m_pDTabBar;
};

#endif // DTABBARWIDGET_H
