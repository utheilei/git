#ifndef DRADIOBUTTONWIDGET_H
#define DRADIOBUTTONWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DRadioButton>
#include <DCheckBox>
#include <QDebug>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DRadioButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DRadioButtonWidget(QWidget *parent = nullptr);
    ~DRadioButtonWidget();

signals:

public slots:
    void slotpDCheBox3StaChange(int iState);

private:
    DCheckBox *m_pDCheckBox3;
};

#endif // DRADIOBUTTONWIDGET_H
