#include "derrormessagewidget.h"

DErrorMessageWidget::DErrorMessageWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("弹出DErrorMessage"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DErrorMessageWidget::slotDPubBtnClicked);
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DErrorMessageWidget::~DErrorMessageWidget()
{

}

void DErrorMessageWidget::slotDPubBtnClicked()
{
    DErrorMessage *pDErrorMessage = new DErrorMessage();
    pDErrorMessage->showMessage(QString(tr("发现一个致命错误！")));
    pDErrorMessage->setWindowTitle(tr("警告"));
    pDErrorMessage->show();
}
