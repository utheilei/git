#include "mainwindow.h"
#include <QTextEdit>
#include <QLabel>
#include <DDesktopServices>
#include <DDialog>
#include <DTabBar>
#include <DSlider>
#include <DDialog>
#include <QString>

MainWindow::MainWindow(DMainWindow *parent)
            : DMainWindow (parent),
              m_pCentralWidget (new QWidget()),
              m_pStackedWidget (new QStackedWidget()),
              m_pDListView (new DListView()),
              m_pSliderWidgt (new SliderWidgt()),
              m_pPushButtonWidget (new PushButtonWidget()),
              m_pWarningButtonWidget (new WarningButtonWidget()),
              m_pDSuggestButtonWidget (new DSuggestButtonWidget()),
              m_pDIconButtonWidget (new DIconButtonWidget),
              m_pDFloatingButtonWidget (new DFloatingButtonWidget()),
              m_pDDialWidget (new DDialWidget()),
              m_pDSrollBarWidget (new DSrollBarWidget()),
              m_pDSwitchButtonWidget (new DSwitchButtonWidget),
              m_pDMessageBoxWidget (new DMessageBoxWidget),
              m_pDButtonBoxWidget (new DButtonBoxWidget),
              m_pDComboBoxWidget (new DComboBoxWidget),
              m_pDFontComboBoxWidget (new DFontComboBoxWidget),
              m_pDRadioButtonWidget (new DRadioButtonWidget),
              m_pDSearchEditWidget (new DSearchEditWidget),
              m_pDLineEditWidget (new DLineEditWidget(this)),
              m_pDIpv4DlineEditWidget (new DIpv4DlineEditWidget),
              m_pDPasswordEditWidget (new DPasswordEditWidget),
              m_pDFileChooserEditWidget (new DFileChooserEditWidget),
              m_pDSpinBoxWidget (new DSpinBoxWidget),
              m_pDTextEditWidget (new DTextEditWidget),
              m_pDCrumbEditWidget (new DCrumbEditWidget),
              m_pDLCDNumberWidget (new DLCDNumberWidget),
              m_pDTitlebarWidget (new DTitlebarWidget),
              m_pDTabBarWidget (new DTabBarWidget),
              m_pDSizegripWidget (new DSizegripWidget),
              m_pDToastWidget (new DToastWidget),
              m_pDStatusBarWidget (new DStatusBarWidget),
              m_pDVerticalLineWidget (new DVerticalLineWidget),
              m_pDWaterProgressWidget (new DWaterProgressWidget),
              m_pDmenuWidget (new DmenuWidget),
              m_pDToolTipWidget (new DToolTipWidget),
              m_pDFrameWidget (new DFrameWidget),
              m_pDInputDialogWidget (new DInputDialogWidget),
              m_pDDialogWidget (new DDialogWidget),
              m_pDDialogButtonBoxWidget (new DDialogButtonBoxWidget),
              m_pDProgressDialogWidget (new DProgressDialogWidget),
              m_pDErrorMessageWidget (new DErrorMessageWidget),
              m_pDSpinnerWidget (new DSpinnerWidget),
              m_pDBackgroundGroupWidget (new DBackgroundGroupWidget),
              m_pDListViewWidget (new DListViewWidget),
              m_pDCommandLinkButtonWidget (new DCommandLinkButtonWidget),
              m_pDProgressBarWidget(new DProgressBarWidget),
              m_pDGroupBoxWidget(new DGroupBoxWidget),
              m_pDTreeWidgetWidget (new DTreeWidgetWidget),
              m_pAnimationWidget (new AnimationWidget),
              m_pReadFileWidget (new ReadFileWidget),
              m_pDFileDialogWidget (new DFileDialogWidget),
              m_pDArrowRectangleWidget (new DArrowRectangleWidget),
              m_pPrintingWidget (new PrintingWidget),
              m_pDKeySequenceEditWidget (new DKeySequenceEditWidget),
              m_pDToolButtonWidget (new DToolButtonWidget),
              m_pQPlainTextEditWidget (new QPlainTextEditWidget)
{
    settingsInit();
    //titlebar()->setIcon(QIcon("audio-volume-high.svg"));

    //titlebar 设置标题栏
    titlebar()->setIcon(QIcon::fromTheme("deepin-editor"));
    const QString str = "";
    titlebar()->setTitle(str); //让标题栏无文字内容显示
    //titlebar()->addWidget(new DButtonBox(this));
    //titlebar()->addWidget(new DSearchEdit(this));
    //titlebar()->setSeparatorVisible(true);
    this->statusBar()->setSizeGripEnabled(true);

    DMenu *pDMenu = new DMenu;
    QAction *newWindowAction(new QAction(tr("New window"), this));
    QAction *newTabAction(new QAction(tr("New tab"), this));
    QAction *openFileAction(new QAction(tr("Open file"), this));
    QAction *saveAction(new QAction(tr("Save"), this));
    QAction *saveAsAction(new QAction(tr("Save as"), this));
    QAction *printAction(new QAction(tr("Print"), this));
    QAction *switchThemeAction(new QAction(tr("Switch theme"), this));
    QAction *settingAction(new QAction(tr("Settings"), this));

    DMenu *pDMenuLevel2 = new DMenu(tr("一级菜单"));
    //pDMenuLevel2->setMinimumWidth(200);
    m_oneAction = new QAction(tr("选项1"), this);
    QAction *twoAction(new QAction(tr("选项2"), this));
    QAction *threeAction(new QAction(tr("选项3"), this));
    QAction *fourAction(new QAction(tr("选项4"), this));
    QAction *fiveAction(new QAction(tr("选项5"), this));
    QAction *sixAction(new QAction(tr("选项6"), this));
    pDMenuLevel2->addAction(m_oneAction);
    pDMenuLevel2->addAction(twoAction);
    pDMenuLevel2->addAction(threeAction);
    pDMenuLevel2->addAction(fourAction);
    pDMenuLevel2->addAction(fiveAction);
    pDMenuLevel2->addAction(sixAction);

    pDMenu->addAction(newWindowAction);
    pDMenu->addAction(newTabAction);
    pDMenu->addAction(openFileAction);
    pDMenu->addSeparator();
    pDMenu->addAction(saveAction);
    pDMenu->addAction(saveAsAction);
    pDMenu->addAction(printAction);
    //pDMenu->addAction(switchThemeAction);
    pDMenu->addSeparator();
    pDMenu->addAction(settingAction);
    pDMenu->addMenu(pDMenuLevel2);
    titlebar()->setMenu(pDMenu);

    connect(m_oneAction, &QAction::triggered, this, &MainWindow::slotActionTriggred);
    connect(settingAction, &QAction::triggered, this, &MainWindow::slotPopupSettingsDialog);

    m_pHBoxLayout = new QHBoxLayout();
    m_pHBoxLayout->addWidget(m_pDListView, 2);
    m_pHBoxLayout->addWidget(m_pStackedWidget, 8);

    QStandardItemModel *pItemModel = new QStandardItemModel(this);

    QStandardItem *pItemAnimation = new QStandardItem("Animation");
    m_pStackedWidget->addWidget(m_pAnimationWidget);
    m_has_ItemName_ItemWiget.insert("Animation", m_pAnimationWidget);
    pItemModel->appendRow(pItemAnimation);

    QStandardItem *pItemReadFile = new QStandardItem("文件读取");
    m_pStackedWidget->addWidget(m_pReadFileWidget);
    m_has_ItemName_ItemWiget.insert("文件读取", m_pReadFileWidget);
    pItemModel->appendRow(pItemReadFile);

    QStandardItem *pItem2 = new QStandardItem("DPushButton");
    m_pStackedWidget->addWidget(m_pPushButtonWidget);
    m_has_ItemName_ItemWiget.insert("DPushButton", m_pPushButtonWidget);
    pItemModel->appendRow(pItem2);

    QStandardItem *pItem3 = new QStandardItem("DWarningButton");
    m_pStackedWidget->addWidget(m_pWarningButtonWidget);
    m_has_ItemName_ItemWiget.insert("DWarningButton", m_pWarningButtonWidget);
    pItemModel->appendRow(pItem3);

    QStandardItem *pItem4 = new QStandardItem("DSuggestButton");
    m_pStackedWidget->addWidget(m_pDSuggestButtonWidget);
    m_has_ItemName_ItemWiget.insert("DSuggestButton", m_pDSuggestButtonWidget);
    pItemModel->appendRow(pItem4);

    QStandardItem *pItemDCommandLinkButton = new QStandardItem("DCommandLinkButton");
    m_pStackedWidget->addWidget(m_pDCommandLinkButtonWidget);
    m_has_ItemName_ItemWiget.insert("DCommandLinkButton", m_pDCommandLinkButtonWidget);
    pItemModel->appendRow(pItemDCommandLinkButton);

    QStandardItem *pItemDToolButton = new QStandardItem("DToolButton");
    m_pStackedWidget->addWidget(m_pDToolButtonWidget);
    m_has_ItemName_ItemWiget.insert("DToolButton", m_pDToolButtonWidget);
    pItemModel->appendRow(pItemDToolButton);

    QStandardItem *pItem5 = new QStandardItem("DIconButton");
    m_pStackedWidget->addWidget(m_pDIconButtonWidget);
    m_has_ItemName_ItemWiget.insert("DIconButton", m_pDIconButtonWidget);
    pItemModel->appendRow(pItem5);

    QStandardItem *pItemDButtonBox = new QStandardItem("DButtonBox");
    m_pStackedWidget->addWidget(m_pDButtonBoxWidget);
    m_has_ItemName_ItemWiget.insert("DButtonBox", m_pDButtonBoxWidget);
    pItemModel->appendRow(pItemDButtonBox);

    QStandardItem *pItem6 = new QStandardItem("DFloatingButton");
    m_pStackedWidget->addWidget(m_pDFloatingButtonWidget);
    m_has_ItemName_ItemWiget.insert("DFloatingButton", m_pDFloatingButtonWidget);
    pItemModel->appendRow(pItem6);

    QStandardItem *pItemDSwitchButton = new QStandardItem("DSwitchButton");
    m_pStackedWidget->addWidget(m_pDSwitchButtonWidget);
    m_has_ItemName_ItemWiget.insert("DSwitchButton", m_pDSwitchButtonWidget);
    pItemModel->appendRow(pItemDSwitchButton);

    QStandardItem *pItemDComboBox = new QStandardItem("DComboBox");
    m_pStackedWidget->addWidget(m_pDComboBoxWidget);
    m_has_ItemName_ItemWiget.insert("DComboBox", m_pDComboBoxWidget);
    pItemModel->appendRow(pItemDComboBox);

    QStandardItem *pItemDFonComboBox = new QStandardItem("DFonComboBox");
    m_pStackedWidget->addWidget(m_pDFontComboBoxWidget);
    m_has_ItemName_ItemWiget.insert("DFonComboBox", m_pDFontComboBoxWidget);
    pItemModel->appendRow(pItemDFonComboBox);

    QStandardItem *pItemDRadioButton = new QStandardItem("DRadioButton");
    m_pStackedWidget->addWidget(m_pDRadioButtonWidget);
    m_has_ItemName_ItemWiget.insert("DRadioButton", m_pDRadioButtonWidget);
    pItemModel->appendRow(pItemDRadioButton);

    QStandardItem *pItemDSearEdit = new QStandardItem("DSearEdit");
    m_pStackedWidget->addWidget(m_pDSearchEditWidget);
    m_has_ItemName_ItemWiget.insert("DSearEdit", m_pDSearchEditWidget);
    pItemModel->appendRow(pItemDSearEdit);

    QStandardItem *pItemDLineEdit = new QStandardItem("DLineEdit");
    m_pStackedWidget->addWidget(m_pDLineEditWidget);
    m_has_ItemName_ItemWiget.insert("DLineEdit", m_pDLineEditWidget);
    pItemModel->appendRow(pItemDLineEdit);

    QStandardItem *pItemDIpv4LineEdit = new QStandardItem("DIpv4LineEdit");
    m_pStackedWidget->addWidget(m_pDIpv4DlineEditWidget);
    m_has_ItemName_ItemWiget.insert("DIpv4LineEdit", m_pDIpv4DlineEditWidget);
    pItemModel->appendRow(pItemDIpv4LineEdit);

    QStandardItem *pItemDPasswordEdit = new QStandardItem("DPasswordEdit");
    m_pStackedWidget->addWidget(m_pDPasswordEditWidget);
    m_has_ItemName_ItemWiget.insert("DPasswordEdit", m_pDPasswordEditWidget);
    pItemModel->appendRow(pItemDPasswordEdit);

    QStandardItem *pItemDFileChooserEdit = new QStandardItem("DFileChooserEdit");
    m_pStackedWidget->addWidget(m_pDFileChooserEditWidget);
    m_has_ItemName_ItemWiget.insert("DFileChooserEdit", m_pDFileChooserEditWidget);
    pItemModel->appendRow(pItemDFileChooserEdit);

    QStandardItem *pItemDSpinBox = new QStandardItem("DSpinBox");
    m_pStackedWidget->addWidget(m_pDSpinBoxWidget);
    m_has_ItemName_ItemWiget.insert("DSpinBox", m_pDSpinBoxWidget);
    pItemModel->appendRow(pItemDSpinBox);

    QStandardItem *pItemDTextEdit = new QStandardItem("DTextEdit");
    m_pStackedWidget->addWidget(m_pDTextEditWidget);
    m_has_ItemName_ItemWiget.insert("DTextEdit", m_pDTextEditWidget);
    pItemModel->appendRow(pItemDTextEdit);

    QStandardItem *pItemQPlainTextEdit = new QStandardItem("QPlainTextEdit");
    m_pStackedWidget->addWidget(m_pQPlainTextEditWidget);
    m_has_ItemName_ItemWiget.insert("QPlainTextEdit", m_pQPlainTextEditWidget);
    pItemModel->appendRow(pItemQPlainTextEdit);

    QStandardItem *pItemDCrumbEdit = new QStandardItem("DCrumbEdit");
    m_pStackedWidget->addWidget(m_pDCrumbEditWidget);
    m_has_ItemName_ItemWiget.insert("DCrumbEdit", m_pDCrumbEditWidget);
    pItemModel->appendRow(pItemDCrumbEdit);

    QStandardItem *pItemDSlider = new QStandardItem("DSlider");
    m_pStackedWidget->addWidget(m_pSliderWidgt);
    m_has_ItemName_ItemWiget.insert("DSlider", m_pSliderWidgt);
    pItemModel->appendRow(pItemDSlider);

    QStandardItem *pItemDDial = new QStandardItem("DDial");
    m_pStackedWidget->addWidget(m_pDDialWidget);
    m_has_ItemName_ItemWiget.insert("DDial", m_pDDialWidget);
    pItemModel->appendRow(pItemDDial);

    QStandardItem *pItemDSrollBar = new QStandardItem("DSrollBar");
    m_pStackedWidget->addWidget(m_pDSrollBarWidget);
    m_has_ItemName_ItemWiget.insert("DSrollBar", m_pDSrollBarWidget);
    pItemModel->appendRow(pItemDSrollBar);

    QStandardItem *pItemDLCDNumber = new QStandardItem("DLCDNumber");
    m_pStackedWidget->addWidget(m_pDLCDNumberWidget);
    m_has_ItemName_ItemWiget.insert("DLCDNumber", m_pDLCDNumberWidget);
    pItemModel->appendRow(pItemDLCDNumber);

    QStandardItem *pItemDTitlebar = new QStandardItem("DTitlebar");
    m_pStackedWidget->addWidget(m_pDTitlebarWidget);
    m_has_ItemName_ItemWiget.insert("DTitlebar", m_pDTitlebarWidget);
    pItemModel->appendRow(pItemDTitlebar);

    QStandardItem *pItemDSizegrip = new QStandardItem("DSizegrip");
    m_pStackedWidget->addWidget(m_pDSizegripWidget);
    m_has_ItemName_ItemWiget.insert("DSizegrip", m_pDSizegripWidget);
    pItemModel->appendRow(pItemDSizegrip);

    QStandardItem *pItemDStatusBar = new QStandardItem("DStatusBar");
    m_pStackedWidget->addWidget(m_pDStatusBarWidget);
    m_has_ItemName_ItemWiget.insert("DStatusBar", m_pDStatusBarWidget);
    pItemModel->appendRow(pItemDStatusBar);

    QStandardItem *pItemDVerticalLine = new QStandardItem("DVerticalLine");
    m_pStackedWidget->addWidget(m_pDVerticalLineWidget);
    m_has_ItemName_ItemWiget.insert("DVerticalLine", m_pDVerticalLineWidget);
    pItemModel->appendRow(pItemDVerticalLine);

    QStandardItem *pItemDProgressBar = new QStandardItem("DProgressBar");
    m_pStackedWidget->addWidget(m_pDProgressBarWidget);
    m_has_ItemName_ItemWiget.insert("DProgressBar", m_pDProgressBarWidget);
    pItemModel->appendRow(pItemDProgressBar);

    QStandardItem *pItemDWaterProgress = new QStandardItem("DWaterProgress");
    m_pStackedWidget->addWidget(m_pDWaterProgressWidget);
    m_has_ItemName_ItemWiget.insert("DWaterProgress", m_pDWaterProgressWidget);
    pItemModel->appendRow(pItemDWaterProgress);

    QStandardItem *pItemDmenu = new QStandardItem("Dmenu");
    m_pStackedWidget->addWidget(m_pDmenuWidget);
    m_has_ItemName_ItemWiget.insert("Dmenu", m_pDmenuWidget);
    pItemModel->appendRow(pItemDmenu);

    QStandardItem *pItemDTabBar = new QStandardItem("DTabBar");
    m_pStackedWidget->addWidget(m_pDTabBarWidget);
    m_has_ItemName_ItemWiget.insert("DTabBar", m_pDTabBarWidget);
    pItemModel->appendRow(pItemDTabBar);

    QStandardItem *pItemDToolTip = new QStandardItem("DToolTip");
    m_pStackedWidget->addWidget(m_pDToolTipWidget);
    m_has_ItemName_ItemWiget.insert("DToolTip", m_pDToolTipWidget);
    pItemModel->appendRow(pItemDToolTip);

    QStandardItem *pItemDMessageBox = new QStandardItem("DMessageBox");
    m_pStackedWidget->addWidget(m_pDMessageBoxWidget);
    m_has_ItemName_ItemWiget.insert("DMessageBox", m_pDMessageBoxWidget);
    pItemModel->appendRow(pItemDMessageBox);

    QStandardItem *pItemDInputDialog = new QStandardItem("DInputDialog");
    m_pStackedWidget->addWidget(m_pDInputDialogWidget);
    m_has_ItemName_ItemWiget.insert("DInputDialog", m_pDInputDialogWidget);
    pItemModel->appendRow(pItemDInputDialog);

    QStandardItem *pItemDDialog = new QStandardItem("DDialog");
    m_pStackedWidget->addWidget(m_pDDialogWidget);
    m_has_ItemName_ItemWiget.insert("DDialog", m_pDDialogWidget);
    pItemModel->appendRow(pItemDDialog);

    QStandardItem *pItemDDialogButtonBox = new QStandardItem("DDialogButtonBox");
    m_pStackedWidget->addWidget(m_pDDialogButtonBoxWidget);
    m_has_ItemName_ItemWiget.insert("DDialogButtonBox", m_pDDialogButtonBoxWidget);
    pItemModel->appendRow(pItemDDialogButtonBox);

    QStandardItem *pItemDProgressDialog = new QStandardItem("DProgressDialog");
    m_pStackedWidget->addWidget(m_pDProgressDialogWidget);
    m_has_ItemName_ItemWiget.insert("DProgressDialog", m_pDProgressDialogWidget);
    pItemModel->appendRow(pItemDProgressDialog);

    QStandardItem *pItemDErrorMessage = new QStandardItem("DErrorMessage");
    m_pStackedWidget->addWidget(m_pDErrorMessageWidget);
    m_has_ItemName_ItemWiget.insert("DErrorMessage", m_pDErrorMessageWidget);
    pItemModel->appendRow(pItemDErrorMessage);

    QStandardItem *pItemDToast = new QStandardItem("DToast");
    m_pStackedWidget->addWidget(m_pDToastWidget);
    m_has_ItemName_ItemWiget.insert("DToast", m_pDToastWidget);
    pItemModel->appendRow(pItemDToast);

    QStandardItem *pItemDSpinner = new QStandardItem("DSpinner");
    m_pStackedWidget->addWidget(m_pDSpinnerWidget);
    m_has_ItemName_ItemWiget.insert("DSpinner", m_pDSpinnerWidget);
    pItemModel->appendRow(pItemDSpinner);

    QStandardItem *pItemDBackgroundGroup = new QStandardItem("DBackgroundGroup");
    m_pStackedWidget->addWidget(m_pDBackgroundGroupWidget);
    m_has_ItemName_ItemWiget.insert("DBackgroundGroup", m_pDBackgroundGroupWidget);
    pItemModel->appendRow(pItemDBackgroundGroup);

    QStandardItem *pItemDListView = new QStandardItem("DListView");
    m_pStackedWidget->addWidget(m_pDListViewWidget);
    m_has_ItemName_ItemWiget.insert("DListView", m_pDListViewWidget);
    pItemModel->appendRow(pItemDListView);

    QStandardItem *pItemDGroupBox = new QStandardItem("DGroupBox");
    m_pStackedWidget->addWidget(m_pDGroupBoxWidget);
    m_has_ItemName_ItemWiget.insert("DGroupBox", m_pDGroupBoxWidget);
    pItemModel->appendRow(pItemDGroupBox);

    QStandardItem *pItemDTreeWidget = new QStandardItem("DTreeWidget");
    m_pStackedWidget->addWidget(m_pDTreeWidgetWidget);
    m_has_ItemName_ItemWiget.insert("DTreeWidget", m_pDTreeWidgetWidget);
    pItemModel->appendRow(pItemDTreeWidget);

    QStandardItem *pItemDFileDialog = new QStandardItem("DFileDialog");
    m_pStackedWidget->addWidget(m_pDFileDialogWidget);
    m_has_ItemName_ItemWiget.insert("DFileDialog", m_pDFileDialogWidget);
    pItemModel->appendRow(pItemDFileDialog);

    QStandardItem *pItemDArrowRectangle = new QStandardItem("DArrowRectangle");
    m_pStackedWidget->addWidget(m_pDArrowRectangleWidget);
    m_has_ItemName_ItemWiget.insert("DArrowRectangle", m_pDArrowRectangleWidget);
    pItemModel->appendRow(pItemDArrowRectangle);

    QStandardItem *pItemDFrame = new QStandardItem("DFrame");
    m_pStackedWidget->addWidget(m_pDFrameWidget);
    m_has_ItemName_ItemWiget.insert("DFrame", m_pDFrameWidget);
    pItemModel->appendRow(pItemDFrame);

    QStandardItem *pItemDKeySequenceEdit = new QStandardItem("DKeySequenceEdit");
    m_pStackedWidget->addWidget(m_pDKeySequenceEditWidget);
    m_has_ItemName_ItemWiget.insert("DKeySequenceEdit", m_pDKeySequenceEditWidget);
    pItemModel->appendRow(pItemDKeySequenceEdit);

    QStandardItem *pItemPrinting = new QStandardItem("Printing");
    m_pStackedWidget->addWidget(m_pPrintingWidget);
    m_has_ItemName_ItemWiget.insert("Printing", m_pPrintingWidget);
    pItemModel->appendRow(pItemPrinting);

    m_pDListView->setModel(pItemModel);
    m_pStackedWidget->setCurrentWidget(m_pPushButtonWidget);
    connect(m_pDListView, &DListView::clicked, this, &MainWindow::slotListViewItemClicked, Qt::QueuedConnection);
    m_pCentralWidget->setLayout(m_pHBoxLayout);
    setCentralWidget(m_pCentralWidget);
}

MainWindow::~MainWindow()
{

}

void MainWindow::slotListViewItemClicked(const QModelIndex &index)
{
    QString strItemName = index.data().toString();
    qDebug() << "strItemName:" << strItemName;

    m_pStackedWidget->setCurrentWidget(m_has_ItemName_ItemWiget.value(strItemName));
}

void MainWindow::slotActionTriggred()
{
    m_oneAction->setIcon(QIcon(":/images/ok.svg"));
}

void MainWindow::settingsInit()
{
    m_strConfDir = DStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
    qDebug() << "m_strConfDir:" <<m_strConfDir;
    QString m_srConfPath = m_strConfDir + QDir::separator() + "dtkdemo.conf";
    qDebug() << "m_strConfDir:" <<m_srConfPath;
}

void MainWindow::slotPopupSettingsDialog()
{
    DSettingsDialog *pDSettingDialog = new DSettingsDialog();

    //创建设置存储后端
    QSettingBackend *pBackend = new QSettingBackend(m_srConfPath);

    //通过json文件创建DSettings对象
    DSettings *pDSettings = DSettings::fromJsonFile(":/resource/settings.json");
    //设置DSettings存储后端
    pDSettings->setBackend(pBackend);

    pDSettingDialog->updateSettings(pDSettings);
    pDSettingDialog->exec();
}
