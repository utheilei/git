#ifndef DFILEDIALOGWIDGET_H
#define DFILEDIALOGWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DFileDialog>
#include <DPushButton>
#include <QFileDialog>
#include <QDebug>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DFileDialogWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DFileDialogWidget(QWidget *parent = nullptr);
    ~DFileDialogWidget();

signals:

public slots:
};

#endif // DFILEDIALOGWIDGET_H
