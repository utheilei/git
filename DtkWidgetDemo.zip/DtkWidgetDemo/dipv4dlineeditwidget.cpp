#include "dipv4dlineeditwidget.h"

DIpv4DlineEditWidget::DIpv4DlineEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->addStretch();
    DIpv4LineEdit *pDIpv4LineEdit = new DIpv4LineEdit();
    connect(pDIpv4LineEdit, &DIpv4LineEdit::focusChanged, this, [=](bool bValue) {
        qDebug() << "bValue:" << bValue;
    });
    pHBoxLayout1->addWidget(pDIpv4LineEdit);
    pHBoxLayout1->addStretch();
    pMainLayout->addLayout(pHBoxLayout1);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDPushButton = new DPushButton(tr("设置只读"));
    pDPushButton->setCheckable(true);
    connect(pDPushButton, &DPushButton::clicked, this, [=] {
        if (pDPushButton->isChecked() == true) {
            pDIpv4LineEdit->setReadOnly(true);
            pDPushButton->setText(tr("取消只读"));
            //pDIpv4LineEdit->setCursorPosition(2);
        }
        else {
            pDIpv4LineEdit->setReadOnly(false);
            pDPushButton->setText(tr("设置只读"));
        }
    });
    pHBoxLayout2->addWidget(pDPushButton);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DIpv4DlineEditWidget::~DIpv4DlineEditWidget()
{

}
