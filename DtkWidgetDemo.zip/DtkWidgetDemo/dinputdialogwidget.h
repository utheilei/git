#ifndef DINPUTDIALOGWIDGET_H
#define DINPUTDIALOGWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DInputDialog>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DInputDialogWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DInputDialogWidget(QWidget *parent = nullptr);
    ~DInputDialogWidget();

signals:

public slots:
    void slotDPubBtnClicked();
};

#endif // DINPUTDIALOGWIDGET_H
