#include "diconbuttonwidget.h"

DIconButtonWidget::DIconButtonWidget(QWidget *parent)
    : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DIconButton *pDIconButtonDecElt = new DIconButton(DStyle::SP_ReduceElement);
    pDIconButtonDecElt->setFlat(true);
    pDIconButtonDecElt->setFixedSize(50, 50);
    DIconButton *pDIconButtonIncElt = new DIconButton(nullptr);
    pDIconButtonIncElt->setIcon(DStyle::SP_IncreaseElement);
    pDIconButtonIncElt->setFixedSize(50, 50);
    pHBoxLayout->addWidget(pDIconButtonDecElt);
    pHBoxLayout->addWidget(pDIconButtonIncElt);
    pMainVBoxLayout->addLayout(pHBoxLayout);
    pHBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DIconButton *pDIconButtonMarkElt = new DIconButton(DStyle::SP_MarkElement);
    pDIconButtonMarkElt->setFixedSize(50, 50);
    DIconButton *pDIconButtonLockElt = new DIconButton(DStyle::SP_LockElement);
    pDIconButtonLockElt->setFixedSize(50, 50);
    pHBoxLayout2->addWidget(pDIconButtonMarkElt);
    pHBoxLayout2->addWidget(pDIconButtonLockElt);
    pMainVBoxLayout->addLayout(pHBoxLayout2);
    pHBoxLayout2->addStretch();

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->addStretch();
    DIconButton *pDIconButtonMeVoloElt = new DIconButton(QStyle::SP_ArrowUp);
    pDIconButtonMeVoloElt->setFixedSize(50, 50);
    DIconButton *pDIconButtonMeVoHiElt = new DIconButton(DStyle::SP_MediaVolumeHighElement);
    pDIconButtonMeVoHiElt->setFixedSize(50, 50);
    pHBoxLayout3->addWidget(pDIconButtonMeVoloElt);
    pHBoxLayout3->addWidget(pDIconButtonMeVoHiElt);
    pMainVBoxLayout->addLayout(pHBoxLayout3);
    pHBoxLayout3->addStretch();

    QHBoxLayout *pHBoxLayout4 = new QHBoxLayout();
    pHBoxLayout4->addStretch();
    DIconButton *pDIconButtonPrev = new DIconButton(DStyle::SP_ArrowPrev);
    connect(pDIconButtonPrev, &DIconButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning.svg"), tr("后退"));
    });
    DIconButton *pDIconButtonNext = new DIconButton(DStyle::SP_ArrowNext);
    connect(pDIconButtonNext, &DIconButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("前进"));
    });

    DIconButton *pDIconButtonLeft = new DIconButton(DStyle::SP_ArrowLeft);
    DIconButton *pDIconButtonRight = new DIconButton(DStyle::SP_ArrowRight);

    pDIconButtonRight->setMinimumSize(50, 50);
    pDIconButtonRight->setCheckable(true);

    pDIconButtonPrev->setMinimumSize(50, 50);
    pDIconButtonNext->setMinimumSize(50, 50);
    pDIconButtonLeft->setMinimumSize(50, 50);


    //pDIconButtonRight->setChecked(true);

    pHBoxLayout4->addWidget(pDIconButtonPrev);
    pHBoxLayout4->addWidget(pDIconButtonNext);
    pHBoxLayout4->addWidget(pDIconButtonLeft);
    pHBoxLayout4->addWidget(pDIconButtonRight);
    pMainVBoxLayout->addLayout(pHBoxLayout4);
    pHBoxLayout4->addStretch();

    QHBoxLayout *pHBoxLayout5 = new QHBoxLayout();
    pHBoxLayout5->addStretch();
    DIconButton *pDIconButtonLogo = new DIconButton(nullptr);
    pDIconButtonLogo->setIcon(QIcon(":/images/logo_24.svg"));
    //pDIconButtonLogo->setMinimumSize(50, 50);
    pDIconButtonLogo->setIconSize(QSize(100, 100));
    DIconButton *pDIconButtonDesk= new DIconButton(QStyle::SP_DesktopIcon);
    pDIconButtonDesk->setFixedSize(50, 50);
    pHBoxLayout5->addWidget(pDIconButtonLogo);
    pHBoxLayout5->addWidget(pDIconButtonDesk);
    pMainVBoxLayout->addLayout(pHBoxLayout5);
    pHBoxLayout5->addStretch();

    this->setLayout(pMainVBoxLayout);
}

DIconButtonWidget::~DIconButtonWidget()
{

}
