#ifndef DSWITCHBUTTONWIDGET_H
#define DSWITCHBUTTONWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DSwitchButton>
#include <DMessageManager>
#include <QDebug>

DWIDGET_USE_NAMESPACE

class DSwitchButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSwitchButtonWidget(QWidget *parent = nullptr);
    ~DSwitchButtonWidget();

signals:

public slots:
};

#endif // DSWITCHBUTTONWIDGET_H
