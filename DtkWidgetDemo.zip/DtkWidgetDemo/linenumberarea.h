#ifndef LINENUMBERAREA_H
#define LINENUMBERAREA_H

#include <QWidget>

class DTextEdit1;
class LineNumberArea : public QWidget
{
    Q_OBJECT

public:
    LineNumberArea(DTextEdit1 *textEdit);
    ~LineNumberArea();

    void paintEvent(QPaintEvent *e) override;
    QSize sizeHint() const;

private:
    DTextEdit1 *m_textEdit;
};

#endif // LINENUMBERAREA_H
