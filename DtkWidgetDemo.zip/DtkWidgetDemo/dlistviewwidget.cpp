#include "dlistviewwidget.h"

DListViewWidget::DListViewWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    m_pDListView = new DListView();
    m_pDListView->setMinimumHeight(500);
    m_pDListView->setBackgroundRole(QPalette::Midlight);
    m_pDListView->setAutoFillBackground(true);
    QStandardItemModel *pItemModel = new QStandardItemModel();

    DStandardItem *pItem1 = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), tr("指纹1"));
    pItemModel->appendRow(pItem1);
    DStandardItem *pItem2 = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), tr("指纹2"));
    pItemModel->appendRow(pItem2);

    m_pDListView->setModel(pItemModel);
    QWidget *pWidgetAdd = new QWidget();
    QHBoxLayout *pWidetHBoxLayout = new QHBoxLayout();
    DCommandLinkButton *pDCommandLinkButton = new DCommandLinkButton(tr("添加指纹"));
    DIconButton *pDIconButton = new DIconButton(nullptr);
    pDIconButton->setIcon(QIcon(":/images/ok.svg"));
    pDIconButton->setFlat(true);
    pWidetHBoxLayout->setAlignment(Qt::AlignCenter);
    pWidetHBoxLayout->addWidget(pDCommandLinkButton);
    pWidetHBoxLayout->addWidget(pDIconButton);
    connect(pDCommandLinkButton, &DCommandLinkButton::clicked, this, [=] {
        m_iNum += 1;
        DStandardItem *pItemFinger = new DStandardItem(QIcon::fromTheme(":/images/ok.svg"), QString("指纹%1").arg(m_iNum));
        pItemModel->appendRow(pItemFinger);
    });
    pWidgetAdd->setLayout(pWidetHBoxLayout);
    m_pDListView->addFooterWidget(pWidgetAdd);
    pHBoxLayout->addWidget(m_pDListView);

    // ======= 第二个 DlistView ============
//    DListView *pDListView2 = new DListView();
//    pDListView->setMinimumHeight(300);
//    pDListView->setBackgroundRole(QPalette::Midlight);
//    pDListView->setAutoFillBackground(true);

//    QWidget *pWidget = new QWidget();
//    QHBoxLayout *pWidetHBoxLayout1 = new QHBoxLayout();
//    pWidetHBoxLayout->addWidget(new DPushButton(tr("按钮1")));
//    pWidget->setLayout(pWidetHBoxLayout);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}
