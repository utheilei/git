#include "dsrollbarwidget.h"

DSrollBarWidget::DSrollBarWidget(QWidget *parent) : QWidget(parent)
{
    QHBoxLayout *pMainHBoxLayout = new QHBoxLayout(this);
    pMainHBoxLayout->setSpacing(10);

    QVBoxLayout *pVBoxLayout = new QVBoxLayout();
    QHBoxLayout *pQHBoxLayout = new QHBoxLayout();
    pMainHBoxLayout->addLayout(pVBoxLayout, 7);
    pMainHBoxLayout->addLayout(pQHBoxLayout, 3);

    m_pLabel = new QLabel("helle");
    m_pLabel->setMaximumWidth(100);
    m_pLabel->setMaximumHeight(100);
    pVBoxLayout->addWidget(m_pLabel);

    DScrollBar *pDScrollBar1 = new DScrollBar(Qt::Horizontal);
    pVBoxLayout->addWidget(pDScrollBar1);

    DScrollBar *pDScrollBar2 = new DScrollBar(Qt::Vertical);
    pQHBoxLayout->addWidget(pDScrollBar2);

    this->setLayout(pMainHBoxLayout);
}
