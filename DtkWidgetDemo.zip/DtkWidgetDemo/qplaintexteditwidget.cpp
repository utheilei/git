#include "qplaintexteditwidget.h"

QPlainTextEditWidget::QPlainTextEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    //pHBoxLayout->addStretch();
    QPlainTextEdit *pPlainTextEdit = new QPlainTextEdit();
    pPlainTextEdit->setMinimumSize(300, 400);
    pHBoxLayout->addWidget(pPlainTextEdit);
    //pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

QPlainTextEditWidget::~QPlainTextEditWidget()
{

}
