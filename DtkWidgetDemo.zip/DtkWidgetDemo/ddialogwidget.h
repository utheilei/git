#ifndef DDIALOGWIDGET_H
#define DDIALOGWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DDialog>
#include <DPushButton>
#include <QString>

DWIDGET_USE_NAMESPACE

class DDialogWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DDialogWidget(QWidget *parent = nullptr);
    ~DDialogWidget();

signals:

public slots:
    void slotDPubBtnClicked();
};

#endif // DDIALOGWIDGET_H
