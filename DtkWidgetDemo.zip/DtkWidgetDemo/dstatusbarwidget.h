#ifndef DSTATUSBARWIDGET_H
#define DSTATUSBARWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
//#include <DStatusBar>
#include <DPushButton>
#include <DMainWindow>
#include <QStatusBar>
#include <DLabel>
#include <QResizeEvent>
#include <DSlider>
#include <DApplicationHelper>

DWIDGET_USE_NAMESPACE

class DStatusBarWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DStatusBarWidget(QWidget *parent = nullptr);

signals:

public slots:
    void slotDPuBtnClicked();
    void slotDPuBtn2Clicked();

private:
    DWidget *m_pDWidget = NULL;
    DMainWindow *m_pMainWindow;

protected:
    void resizeEvent(QResizeEvent *event) override;
};

#endif // DSTATUSBARWIDGET_H
