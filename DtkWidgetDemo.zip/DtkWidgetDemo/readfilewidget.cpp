#include "readfilewidget.h"

ReadFileWidget::ReadFileWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DLabel *pLabel  = new DLabel();
    pLabel->setScaledContents(true);
    pLabel->setMinimumSize(400, 400);
    pHBoxLayout2->addWidget(pLabel);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("打开文件"));
    pDPusBtn->setMinimumSize(100, 36);
    connect(pDPusBtn, &DPushButton::clicked, this, [=] {
        QString strFilePath = QFileDialog::getOpenFileName();
        qDebug() << "strFilePath: " << strFilePath;
        FileLoadThread *pFileLoadThread = new FileLoadThread(strFilePath);
        connect(pFileLoadThread, &FileLoadThread::finished, pFileLoadThread, &FileLoadThread::deleteLater);
        connect(pFileLoadThread, &FileLoadThread::sigLoadPixmapFinished, this, [=](QPixmap pixmap) {
            pLabel->setPixmap(pixmap);
        });
        pFileLoadThread->start();
    });
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

ReadFileWidget::~ReadFileWidget()
{

}
