#ifndef DSIZEGRIPWIDGET_H
#define DSIZEGRIPWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPushButton>
#include <DMainWindow>
#include <DDialog>
#include <QStatusBar>
//#include <dsizegripwidget.h>

DWIDGET_USE_NAMESPACE

class DSizegripWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSizegripWidget(QWidget *parent = nullptr);

signals:

public slots:
    void slotDPuBtnClicked();
    void slotDPuBtn2Clicked();
};

#endif // DSIZEGRIPWIDGET_H
