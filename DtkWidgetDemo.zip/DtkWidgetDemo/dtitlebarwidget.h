#ifndef DTITLEBARWIDGET_H
#define DTITLEBARWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DTitlebar>
#include <DPushButton>
#include <DMainWindow>
#include <DSearchEdit>
#include <DButtonBox>
#include <DTabBar>
#include <DIconButton>

DWIDGET_USE_NAMESPACE

class DTitlebarWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DTitlebarWidget(QWidget *parent = nullptr);
    ~DTitlebarWidget();

signals:

public slots:
    void slotDPuBtnLogoClicked();
    void slotDPuBtnSearEditClicked();
    void slotDPuBtnButtonBoxClicked();
    void slotDPuBtnTabBarClicked();
    void slotDPuBtnIconBtnClicked();
};

#endif // DTITLEBARWIDGET_H
