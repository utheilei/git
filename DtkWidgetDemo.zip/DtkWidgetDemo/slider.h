#ifndef SLIDER_H
#define SLIDER_H

#include <QWidget>
#include <QHBoxLayout>
#include <DSlider>
#include <QLabel>
#include <QIcon>

DWIDGET_USE_NAMESPACE

class SliderWidgt : public QWidget
{
    Q_OBJECT
public:
    SliderWidgt(QWidget *parent = 0);
    ~SliderWidgt();

public slots:
    void slotSliderValueChange(int value);

private:
    QLabel *m_pLabel;
};

#endif // SLIDER_H
