#include "dswitchbuttonwidget.h"

DSwitchButtonWidget::DSwitchButtonWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(30);

    DSwitchButton *pDSwitchButton1 = new DSwitchButton();
    connect(pDSwitchButton1, &DSwitchButton::clicked, this, [=](bool bValue) {
        if (bValue == true) {
            DMessageManager::instance()->sendMessage(this, QIcon(tr(":/images/ok.svg")), tr("开启"));
        }
        else {
            DMessageManager::instance()->sendMessage(this, QIcon(tr(":/images/warning.svg")), tr("关闭"));
        }
    });
    pHBoxLayout->addWidget(pDSwitchButton1);

    DSwitchButton *pDSwitchButton2 = new DSwitchButton();
    pHBoxLayout->addWidget(pDSwitchButton2);
    pDSwitchButton2->setDisabled(true);

    DSwitchButton *pDSwitchButton3 = new DSwitchButton();
    pDSwitchButton3->setChecked(true);
    pHBoxLayout->addWidget(pDSwitchButton3);
    pDSwitchButton3->setFocusPolicy(Qt::StrongFocus);

    DSwitchButton *pDSwitchButton4 = new DSwitchButton();
    pHBoxLayout->addWidget(pDSwitchButton4);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}

DSwitchButtonWidget::~DSwitchButtonWidget()
{

}
