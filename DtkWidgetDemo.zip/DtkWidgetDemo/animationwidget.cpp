#include "animationwidget.h"

AnimationWidget::AnimationWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->addStretch();
    DIconButton *pDIconButton = new DIconButton(DStyle::SP_ExpandElement);
    pDIconButton->setVisible(true);

    pHBoxLayout1->addWidget(pDIconButton);
    pHBoxLayout1->addStretch();
    pMainLayout->addLayout(pHBoxLayout1);
    int iMsecs = 5000;

    QPropertyAnimation *pAnimationGeometry = new QPropertyAnimation(pDIconButton, "geometry"); // geometry windowOpacity
    pAnimationGeometry->setDuration(iMsecs);
    QEasingCurve curve = QEasingCurve::OutExpo;
    pAnimationGeometry->setEasingCurve(curve);

    pAnimationGeometry->setStartValue(QRect(100, 100, 300, 300));
    pAnimationGeometry->setEndValue(QRect(150, 150, 128, 128));

    QGraphicsOpacityEffect *pButtonOpacity = new QGraphicsOpacityEffect(pDIconButton);
    pButtonOpacity->setOpacity(1);
    pDIconButton->setGraphicsEffect(pButtonOpacity);

    QPropertyAnimation *pAnimationOpacity = new QPropertyAnimation(pDIconButton, "opacity");
    pAnimationOpacity->setDuration(iMsecs);
    pAnimationOpacity->setStartValue(1);
    pAnimationOpacity->setEndValue(0);
    //pAnimationOpacity->start(QAbstractAnimation::DeleteWhenStopped);


//    QParallelAnimationGroup *pAnimationGroup = new QParallelAnimationGroup();
//    pAnimationGroup->addAnimation(pAnimationGeometry);
//    pAnimationGroup->addAnimation(pAnimationOpacity);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDPushButton = new DPushButton(tr("开始动画"));
    connect(pDPushButton, &DPushButton::clicked, this, [=] {
        pAnimationGeometry->start();
        //pAnimationGroup->start();
    });
    pDPushButton->setCheckable(true);
    pHBoxLayout2->addWidget(pDPushButton);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}
