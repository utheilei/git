#ifndef DVERTICALLINEWIDGET_H
#define DVERTICALLINEWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DVerticalLine>
#include <DHorizontalLine>
#include <DPalette>
#include <DApplicationHelper>
#include <QSizePolicy>

DGUI_USE_NAMESPACE
DWIDGET_USE_NAMESPACE

class DVerticalLineWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DVerticalLineWidget(QWidget *parent = nullptr);
    ~DVerticalLineWidget();

signals:

public slots:
};

#endif // DVERTICALLINEWIDGET_H
