#include "dtooltipwidget.h"

DToolTipWidget::DToolTipWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DToolTip *pDToolTip = new DToolTip(tr("这是DToolTip控件"), true);
    pHBoxLayout->addWidget(pDToolTip);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("显示临时DToolTop"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DToolTipWidget::slotDPusBtnClicked);
    pHBoxLayout2->addWidget(pDPusBtn);
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DToolTipWidget::~DToolTipWidget()
{

}

void DToolTipWidget::slotDPusBtnClicked()
{
    DToolTip *m_pDToolTip2 = new DToolTip(tr("临时DToolTip控件"), true);
    m_pDToolTip2->setParent(this);
    m_pDToolTip2->show(QPoint(50,100), 5000);
}
