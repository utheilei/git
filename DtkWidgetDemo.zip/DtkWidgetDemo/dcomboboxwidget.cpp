#include "dcomboboxwidget.h"

DComboBoxWidget::DComboBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(10);

    DDial *p = new DDial();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DComboBox *pDComboBox = new DComboBox();
    pDComboBox->setFixedWidth(200);
    pDComboBox->addItem(tr("选项1"));
    pDComboBox->addItem(tr("选项2"));
    pDComboBox->addItem(tr("选项3"));
    pDComboBox->addItem(tr("选项4"));
    pDComboBox->addItem(tr("选项5"));
    pHBoxLayout->addWidget(pDComboBox);
    pHBoxLayout->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DComboBox *pDComboBox2 = new DComboBox();
    pDComboBox2->setFixedWidth(200);
    pDComboBox2->setEditable(true);
    pDComboBox2->insertItem(0, QIcon(":/images/logo_24.svg"), "选项1");
    pDComboBox2->insertItem(1, QIcon(":/images/warning.svg"), "选项2");
    pDComboBox2->insertItem(2, QIcon(":/images/warning_back.svg"), "选项3");
    pDComboBox2->insertItem(3, QIcon(":/images/ok.svg"), "选项4");
    pDComboBox2->insertItem(4, QIcon(":/images/logo_24.svg"), "选项5");
    pHBoxLayout2->addWidget(pDComboBox2);
    pHBoxLayout2->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->addStretch();
    DComboBox *pDComboBox3 = new DComboBox();
    pDComboBox3->setFixedWidth(200);
    //pDComboBox3->setEditable(true);
    pDComboBox3->insertItem(0, QIcon(":/images/logo_24.svg"), "选项1");
    pDComboBox3->insertItem(1, QIcon(":/images/warning.svg"), "选项2");
    pDComboBox3->insertSeparator(1);
    pDComboBox3->insertItem(2, QIcon(":/images/warning_back.svg"), "选项3");
    pDComboBox3->insertSeparator(2);
    pDComboBox3->insertItem(3, QIcon(":/images/ok.svg"), "选项4");
    pDComboBox3->insertItem(4, QIcon(":/images/logo_24.svg"), "选项5");

    //pDComboBox3->insertSeparator(3);
    //pDComboBox3->insertSeparator(4);
    pHBoxLayout3->addWidget(pDComboBox3);
    pHBoxLayout3->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout3);

    this->setLayout(pMainVBoxLayout);
}

DComboBoxWidget::~DComboBoxWidget()
{

}
