#ifndef DLISTVIEWWIDGET_H
#define DLISTVIEWWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DListView>
#include <DStandardItem>
#include <DPushButton>
#include <DCommandLinkButton>
#include <DIconButton>

DWIDGET_USE_NAMESPACE

class DListViewWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DListViewWidget(QWidget *parent = nullptr);

signals:

public slots:

private:
    int m_iNum = 2;
    DListView *m_pDListView;
};

#endif // DLISTVIEWWIDGET_H
