#ifndef DMENUWIDGET_H
#define DMENUWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DMenu>

DWIDGET_USE_NAMESPACE

class DmenuWidget : public QWidget
{
public:
    DmenuWidget(QWidget *parent = nullptr);
    ~DmenuWidget();

public slots:
    void slotActionTriggred();

private:
    QAction *m_oneAction;
};

#endif // DMENUWIDGET_H
