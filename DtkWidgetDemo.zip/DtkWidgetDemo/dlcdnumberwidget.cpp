#include "dlcdnumberwidget.h"

DLCDNumberWidget::DLCDNumberWidget(QWidget *parent) : QWidget(parent)
{
    QTimer *pTimer = new QTimer();
    pTimer->setInterval(1000);
    pTimer->start();
    connect(pTimer, &QTimer::timeout, this, &DLCDNumberWidget::slotOnTimerOut);

    m_pTimer2 = new QTimer();
    m_pTimer2->setInterval(1000);
    connect(m_pTimer2, &QTimer::timeout, this, &DLCDNumberWidget::slotOnTimer2Out);

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    m_pDLCDNumber = new DLCDNumber();
    m_pDLCDNumber->setMode(QLCDNumber::Dec);
    m_pDLCDNumber->display(0);
    m_pDLCDNumber->setDigitCount(8);
    m_pDLCDNumber->setFixedSize(150, 40);
    pHBoxLayout->addWidget(m_pDLCDNumber);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DLCDNumber *pDLCDNumber2 = new DLCDNumber();
    pDLCDNumber2->setMode(QLCDNumber::Hex);
    pDLCDNumber2->setSegmentStyle(QLCDNumber::Outline);
    pDLCDNumber2->display(0x124);
    pDLCDNumber2->setFixedSize(150, 40);
    pHBoxLayout2->addWidget(pDLCDNumber2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->setSpacing(0);
    pHBoxLayout3->addStretch();
    m_pDLCDNumber3 = new DLCDNumber();
    m_pDLCDNumber3->setMode(QLCDNumber::Dec);
    m_pDLCDNumber3->setSegmentStyle(QLCDNumber::Flat);
    m_pDLCDNumber3->display(000);
    m_pDLCDNumber3->setFixedSize(150, 40);
    pHBoxLayout3->addWidget(m_pDLCDNumber3);
    pHBoxLayout3->addStretch();
    pMainLayout->addLayout(pHBoxLayout3);

    QHBoxLayout *pHBoxLayout31 = new QHBoxLayout();
    pHBoxLayout31->setSpacing(0);
    pHBoxLayout31->addStretch();
    m_pDPushButton1 = new DPushButton(QStringLiteral("开始计时"));
    m_pDPushButton1->setFixedSize(80, 36);
    m_pDPushButton1->setCheckable(true);
    connect(m_pDPushButton1, &DPushButton::clicked, this, &DLCDNumberWidget::slotDPushBtnClicked);
    DPushButton *pDPushButton2 = new DPushButton(QStringLiteral("清零"));
    pDPushButton2->setFixedSize(80, 36);
    connect(pDPushButton2, &DPushButton::clicked, this, &DLCDNumberWidget::slotDPushBtn2Clicked);
    pHBoxLayout31->addWidget(m_pDPushButton1);
    pHBoxLayout31->addWidget(pDPushButton2);
    pHBoxLayout31->addStretch();
    pMainLayout->addLayout(pHBoxLayout31);

    QHBoxLayout *pHBoxLayout4 = new QHBoxLayout();
    pHBoxLayout4->setSpacing(0);
    pHBoxLayout4->addStretch();
    m_pDLCDNumber4 = new DLCDNumber();
    m_pDLCDNumber4->setMode(QLCDNumber::Dec);
    m_pDLCDNumber4->setSegmentStyle(QLCDNumber::Filled);
    m_pDLCDNumber4->display(00);
    m_pDLCDNumber4->setFixedSize(150, 40);
    pHBoxLayout4->addWidget(m_pDLCDNumber4);
    pHBoxLayout4->addStretch();
    pMainLayout->addLayout(pHBoxLayout4);

    QHBoxLayout *pHBoxLayout5 = new QHBoxLayout();
    pHBoxLayout5->setSpacing(0);
    pHBoxLayout5->addStretch();
    DSlider *pDSlider = new DSlider();
    pDSlider->slider()->setMinimum(0);
    pDSlider->slider()->setMaximum(1000);
    connect(pDSlider, &DSlider::valueChanged, this, &DLCDNumberWidget::slotDSliderValueChange);
    pHBoxLayout5->addWidget(pDSlider);
    pHBoxLayout5->addStretch();
    pMainLayout->addLayout(pHBoxLayout5);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DLCDNumberWidget::~DLCDNumberWidget()
{

}

void DLCDNumberWidget::slotDSliderValueChange(int value)
{
    m_pDLCDNumber4->display(value);
}

void DLCDNumberWidget::slotOnTimerOut()
{
    QTime time = QTime::currentTime();
    m_pDLCDNumber->display(time.toString("hh:mm:ss"));
}

void DLCDNumberWidget::slotOnTimer2Out()
{
    displayNumber += 1;
    m_pDLCDNumber3->display(QString::number(displayNumber));
}

void DLCDNumberWidget::slotDPushBtnClicked(bool bChecked)
{
    qDebug() << "In function [" << __FUNCTION__ << "]. isChecked: " << m_pDPushButton1->isChecked();
    if(m_pDPushButton1->isChecked() == true)
    {
        m_pTimer2->start();
        m_pDPushButton1->setText(QStringLiteral("暂停"));
    }
    else
    {
        m_pTimer2->stop();
        m_pDPushButton1->setText(QStringLiteral("开始计时"));
    }
}

void DLCDNumberWidget::slotDPushBtn2Clicked()
{
    displayNumber = 0;
    m_pDLCDNumber3->display(displayNumber);
}
