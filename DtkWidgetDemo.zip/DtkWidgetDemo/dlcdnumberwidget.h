#ifndef DLCDNUMBERWIDGET_H
#define DLCDNUMBERWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DLCDNumber>
#include <DSlider>
#include <QTimer>
#include <QTime>
#include <DPushButton>
#include <QDebug>

DWIDGET_USE_NAMESPACE

class DLCDNumberWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DLCDNumberWidget(QWidget *parent = nullptr);
    ~DLCDNumberWidget();

signals:

public slots:
    void slotDSliderValueChange(int value);
    void slotOnTimerOut();
    void slotOnTimer2Out();
    void slotDPushBtnClicked(bool bChecked);
    void slotDPushBtn2Clicked();

private:
    DLCDNumber *m_pDLCDNumber4;
    DLCDNumber *m_pDLCDNumber;
    DPushButton *m_pDPushButton1;
    DLCDNumber *m_pDLCDNumber3;
    int displayNumber = 0;
    QTimer *m_pTimer2;
};

#endif // DLCDNUMBERWIDGET_H
