#include "dspinboxwidget.h"

DSpinBoxWidget::DSpinBoxWidget(QWidget *parent) : QWidget(parent)
{
    /********************************************×××**
     * DSpinBox dtk类没有做封装，直接和QSpinBox一样用
     * *****************************************×××**/

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DSpinBox *pDSpinBox = new DSpinBox();
    pDSpinBox->setFixedWidth(300);
    pDSpinBox->setRange(0, 50);
    pDSpinBox->setPrefix("$");
    pHBoxLayout->addWidget(pDSpinBox);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DSpinBox *pDSpinBox2 = new DSpinBox();
    pDSpinBox2->setFixedWidth(300);
    pDSpinBox->setRange(0, 50);
    pDSpinBox2->setSuffix("%");
    pDSpinBox2->setSingleStep(10);
    pDSpinBox2->setWrapping(true);
    pHBoxLayout2->addWidget(pDSpinBox2);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DSpinBoxWidget::~DSpinBoxWidget()
{

}
