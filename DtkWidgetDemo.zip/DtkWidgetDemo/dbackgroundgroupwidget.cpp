#include "dbackgroundgroupwidget.h"
#include <QDebug>

DBackgroundGroupWidget::DBackgroundGroupWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QVBoxLayout *pBtnVBoxLayout = new QVBoxLayout();
    pBtnVBoxLayout->setSpacing(0);
    DPushButton *pDPusBtn1 = new DPushButton(tr("按钮1"));
    DPushButton *pDPusBtn2 = new DPushButton(tr("按钮2"));
    DPushButton *pDPusBtn3 = new DPushButton(tr("按钮3"));
    DPushButton *pDPusBtn4 = new DPushButton(tr("按钮4"));
    DPushButton *pDPusBtn5 = new DPushButton(tr("按钮5"));
    pBtnVBoxLayout->addWidget(pDPusBtn1);
    pBtnVBoxLayout->addWidget(pDPusBtn2);
    pBtnVBoxLayout->addWidget(pDPusBtn3);
    pBtnVBoxLayout->addWidget(pDPusBtn4);
    pBtnVBoxLayout->addWidget(pDPusBtn5);

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DBackgroundGroup *pDBackgroundGroup = new DBackgroundGroup(pBtnVBoxLayout); //创建的同时把layout set进去
    pDBackgroundGroup->setMinimumWidth(200);
    //pDBackgroundGroup->setBackgroundRole(QPalette::LinkVisited);
    DPalette pa = DApplicationHelper::instance()->palette(pDBackgroundGroup);
    //DPalette pa = pDBackgroundGroup->palette();
    QColor color = pa.linkVisited().color();
    qDebug()<<color;
    pa.setColor(DPalette::Base, color);
    pDBackgroundGroup->setPalette(pa);
    pHBoxLayout->addWidget(pDBackgroundGroup);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QMargins margins(5, 5, 5, 5);
    pDBackgroundGroup->setItemMargins(margins);
    pDBackgroundGroup->setItemSpacing(2);
    pDBackgroundGroup->setUseWidgetBackground(true);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}
