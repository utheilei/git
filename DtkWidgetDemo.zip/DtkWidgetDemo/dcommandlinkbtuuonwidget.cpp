#include "dcommandlinkbtuuonwidget.h"

DCommandLinkButtonWidget::DCommandLinkButtonWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    //一个普通按钮
    DCommandLinkButton *pDCommandLinkButton = new DCommandLinkButton(tr("编辑"));
    connect(pDCommandLinkButton, &DCommandLinkButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("编辑被点击"));
    });
    pDCommandLinkButton->setMinimumSize(150, 100);
    pHBoxLayout->addWidget(pDCommandLinkButton);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}
