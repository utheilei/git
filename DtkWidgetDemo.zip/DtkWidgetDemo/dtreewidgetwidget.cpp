#include "dtreewidgetwidget.h"

DTreeWidgetWidget::DTreeWidgetWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DTreeWidget *pDtreeWidget = new DTreeWidget();
    QTreeWidgetItem *pItemFriends = new  QTreeWidgetItem(pDtreeWidget, QStringList(tr("我的好友")));
    pDtreeWidget->addTopLevelItem(pItemFriends);
    QTreeWidgetItem *pItem11 = new  QTreeWidgetItem(pItemFriends, QStringList(tr("好友1")));
    QTreeWidgetItem *pItem12 = new  QTreeWidgetItem(pItemFriends, QStringList(tr("好友2")));
    QTreeWidgetItem *pItem13 = new  QTreeWidgetItem(pItemFriends, QStringList(tr("好友3")));
    QTreeWidgetItem *pItem14 = new  QTreeWidgetItem(pItemFriends, QStringList(tr("好友4")));

    QTreeWidgetItem *pItemClassmates = new  QTreeWidgetItem(pDtreeWidget, QStringList(tr("同学")));
    pDtreeWidget->addTopLevelItem(pItemClassmates);
    QTreeWidgetItem *pItem21 = new  QTreeWidgetItem(pItemClassmates, QStringList(tr("同学1")));
    QTreeWidgetItem *pItem22 = new  QTreeWidgetItem(pItemClassmates, QStringList(tr("同学2")));
    QTreeWidgetItem *pItem23 = new  QTreeWidgetItem(pItemClassmates, QStringList(tr("同学3")));
    QTreeWidgetItem *pItem24 = new  QTreeWidgetItem(pItemClassmates, QStringList(tr("同学4")));

    pHBoxLayout->addWidget(pDtreeWidget);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DTreeWidgetWidget::~DTreeWidgetWidget()
{

}
