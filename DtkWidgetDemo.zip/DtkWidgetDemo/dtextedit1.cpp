#include "dtextedit1.h"

//#include <KF5/KSyntaxHighlighting/definition.h>
//#include <KF5/KSyntaxHighlighting/syntaxhighlighter.h>
//#include <KF5/KSyntaxHighlighting/theme.h>

#include <QAbstractTextDocumentLayout>
#include <QTextDocumentFragment>
#include <DDesktopServices>
#include <QApplication>
#include <DSettingsGroup>
#include <DSettingsOption>
#include <DSettings>
#include <QClipboard>
#include <QFileInfo>
#include <QDebug>
#include <QPainter>
#include <QScroller>
#include <QScrollBar>
#include <QStyleFactory>
#include <QTextBlock>
#include <QMimeData>
#include <QTimer>
#include <DTextEdit>

DTextEdit1::DTextEdit1(DTextEdit *parent) : DTextEdit(parent)
{
    m_lineNumbersColor = QColor("ffffff");
    lineNumberArea = new LineNumberArea(this);

    this->setLineWrapMode(DTextEdit1::WidgetWidth);
    this->setLineWrapColumnOrWidth(this->width());
    setViewportMargins(10, 10, 10, 10);

    // Init widgets.
    connect(this->verticalScrollBar(), &QScrollBar::valueChanged, this, &DTextEdit1::updateLineNumber);
    connect(this, &QTextEdit::textChanged, this, [this]() {
        updateLineNumber();
    });
}

DTextEdit1::~DTextEdit1()
{

}

int DTextEdit1::blockCount() const
{
    qDebug() << "In function [" << __FUNCTION__ << "]. document()->blockCount():" << document()->blockCount();
    return document()->blockCount();
}

void DTextEdit1::resizeEvent(QResizeEvent *event)
{
    qDebug() << "width,height:" << this->width() << "," << this->height();
    qDebug() << "this->document()->size()" << this->document()->size();

    QTextEdit::resizeEvent(event);
}

void DTextEdit1::updateLineNumber()
{
    // Update line number painter.

    int blockSize = QString::number(blockCount()).size();
    qDebug() << "In function [" << __FUNCTION__ << "]. blockSize:" << blockSize;

    lineNumberArea->setFixedWidth(blockSize * fontMetrics().width('9') + m_lineNumberPaddingX * 4);
    lineNumberArea->update();
}

void DTextEdit1::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    QPainter painter(lineNumberArea);
    //painter.fillRect(event->rect(), m_backgroundColor);
    QColor m_backgroundColor = QColor("#252525");

    QColor lineNumberAreaBackgroundColor;
    if (QColor(m_backgroundColor).lightness() < 128) {
        lineNumberAreaBackgroundColor = QColor("#ffffff");
        lineNumberAreaBackgroundColor.setAlphaF(0.05);
    } else {
        lineNumberAreaBackgroundColor = QColor("#000000");
        lineNumberAreaBackgroundColor.setAlphaF(0.05);
    }
    painter.fillRect(event->rect(), lineNumberAreaBackgroundColor);

    int blockNumber = getFirstVisibleBlockId();
    QTextBlock block = document()->findBlockByNumber(blockNumber);
    QTextBlock prev_block = (blockNumber > 0) ? document()->findBlockByNumber(blockNumber-1) : block;
    int translate_y = (blockNumber > 0) ? -verticalScrollBar()->sliderPosition() : 0;

    int top = this->viewport()->geometry().top();

    // Adjust text position according to the previous "non entirely visible" block
    // if applicable. Also takes in consideration the document's margin offset.
    int additional_margin;
    if (blockNumber == 0)
        // Simply adjust to document's margin
        additional_margin = document()->documentMargin() -1 - this->verticalScrollBar()->sliderPosition();
    else
        // Getting the height of the visible part of the previous "non entirely visible" block
        additional_margin = document()->documentLayout()->blockBoundingRect(prev_block)
                .translated(0, translate_y).intersected(this->viewport()->geometry()).height();

    // Shift the starting point
    top += additional_margin;

    int bottom = top + document()->documentLayout()->blockBoundingRect(block).height();

    //Utils::setFontSize(painter, document()->defaultFont().pointSize() - 2);
    // Draw the numbers (displaying the current line number in green)
    while (block.isValid() && top <= event->rect().bottom()) {
        if (block.isVisible() && bottom >= event->rect().top()) {
            if (blockNumber + 1 == m_markStartLine) {
                painter.setPen(m_regionMarkerColor);
            } else {
                painter.setPen(m_lineNumbersColor);
            }

//            painter.drawText(0, top,
//                             lineNumberArea->width(), fontMetrics().height(),
//                             Qt::AlignTop | Qt::AlignHCenter, QString::number(blockNumber + 1));

              int iFontSize = 0;
              QString strBlockNumber =  QString::number(blockNumber + 1);
              //iFontSize = currentFont().pixelSize();
              //() << "In function [" << __FUNCTION__ << "]. iFontSize:" << iFontSize;

              painter.drawText(0, top,
                                lineNumberArea->width(), fontMetrics().height(),
                                Qt::AlignTop | Qt::AlignHCenter, strBlockNumber);
        }

        block = block.next();
        top = bottom;
        bottom = top + document()->documentLayout()->blockBoundingRect(block).height();
        ++blockNumber;
    }
}

int DTextEdit1::getFirstVisibleBlockId() const
{
    // Detect the first block for which bounding rect - once translated
    // in absolute coordinated - is contained by the editor's text area

    // Costly way of doing but since "blockBoundingGeometry(...)" doesn't
    // exists for "QTextEdit"...

    QTextCursor curs = QTextCursor(this->document());
    curs.movePosition(QTextCursor::Start);
    for (int i=0; i < this->document()->blockCount(); ++i) {
        QTextBlock block = curs.block();

        QRect r1 = this->viewport()->geometry();
        QRect r2 = this->document()->documentLayout()->blockBoundingRect(block).translated(
                    this->viewport()->geometry().x(), this->viewport()->geometry().y() - (
                        this->verticalScrollBar()->sliderPosition())).toRect();

        if (r1.contains(r2, true)) {
            return i;
        }

        curs.movePosition(QTextCursor::NextBlock);
    }

    return 0;
}

int DTextEdit1::lineNumberAreaWidth()
{
    int digits = 1;
    int max = qMax(1, this->document()->blockCount());
    while (max >= 10) {
        max /= 10;
        ++digits;
    }

    int space = 13 +  fontMetrics().width(QLatin1Char('9')) * (digits);

    return space;
}
