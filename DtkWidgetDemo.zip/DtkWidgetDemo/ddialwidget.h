#ifndef DDIALWIDGET_H
#define DDIALWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DDial>

DWIDGET_USE_NAMESPACE

class DDialWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DDialWidget(QWidget *parent = nullptr);
    ~DDialWidget();

signals:

public slots:
};

#endif // DDIALWIDGET_H
