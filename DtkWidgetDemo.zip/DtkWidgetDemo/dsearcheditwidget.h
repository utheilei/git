#ifndef DSEARCHEDITWIDGET_H
#define DSEARCHEDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DSearchEdit>
#include <DPushButton>
#include <DMainWindow>
#include <DTitlebar>
#include <QDebug>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DSearchEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DSearchEditWidget(QWidget *parent = nullptr);
    ~DSearchEditWidget();

signals:

public slots:
    void slotDPusBtnClicked();
    void slotDSearchTextEdit(const QString &);
    void slotEditingFinished();

private:
    DSearchEdit *m_pDSearchEdit;
};

#endif // DSEARCHEDITWIDGET_H
