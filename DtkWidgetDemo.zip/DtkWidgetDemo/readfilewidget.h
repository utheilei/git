#ifndef READFILEWIDGET_H
#define READFILEWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPushButton>
#include <QFileDialog>
#include "fileloadthread.h"
#include <DLabel>

DWIDGET_USE_NAMESPACE

class ReadFileWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ReadFileWidget(QWidget *parent = nullptr);
    ~ReadFileWidget();

signals:

public slots:
};

#endif // READFILEWIDGET_H
