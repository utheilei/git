#ifndef DTOOLTIPWIDGET_H
#define DTOOLTIPWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DToolTip>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DToolTipWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DToolTipWidget(QWidget *parent = nullptr);
    ~DToolTipWidget();

signals:

public slots:
    void slotDPusBtnClicked();

private:
    DToolTip *m_pDToolTip2;
};

#endif // DTOOLTIPWIDGET_H
