#include "dinputdialogwidget.h"

DInputDialogWidget::DInputDialogWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("弹出DInputDialog"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DInputDialogWidget::slotDPubBtnClicked);
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DInputDialogWidget::~DInputDialogWidget()
{

}

void DInputDialogWidget::slotDPubBtnClicked()
{
    DInputDialog *pDInputDialog = new DInputDialog();
    pDInputDialog->show();
}
