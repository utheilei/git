#include "pushbutton.h"

PushButtonWidget::PushButtonWidget(QWidget *parent)
    : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(30);
    //一个普通按钮
    DPushButton *pDPushButton1 = new DPushButton(tr("恢复"));
    pDPushButton1->setMinimumWidth(100);//最小宽度
    pDPushButton1->setMinimumHeight(50);//最小高度
    connect(pDPushButton1, &DPushButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    pHBoxLayout->addWidget(pDPushButton1);

    DPushButton *pDPushButton2 = new DPushButton(tr("disabled"));
    pDPushButton2->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDPushButton2);
    pDPushButton2->setDisabled(true);

    DPushButton *pDPushButton3 = new DPushButton(tr("focus"));
    pDPushButton3->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDPushButton3);
    //setFocusProxy(pDPushButton3);
    pDPushButton3->setFocusPolicy(Qt::StrongFocus);

    DPushButton *pDPushButton4 = new DPushButton(tr("按钮设置颜色"));
    pDPushButton4->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDPushButton4);
    DPalette pa = DApplicationHelper::instance()->palette(pDPushButton4);
    QColor color = pa.textWarning().color();
    pa.setColor(DPalette::ButtonText, color);
    pDPushButton4->setPalette(pa);

    QPushButton *pPushBtn = new QPushButton(QStringLiteral("QPushButton"));
    QPalette paQPushBtn = pPushBtn->palette();
    QColor color1 = pPushBtn->palette().linkVisited().color();
    color.setAlphaF(0.5);
    paQPushBtn.setColor(QPalette::ButtonText, color1);
    pPushBtn->setPalette(paQPushBtn);
    pPushBtn->setMinimumWidth(100);
    pHBoxLayout->addWidget(pPushBtn);

//    DPalette paTextEdit = DApplicationHelper::instance()->palette(pDTextEdit);
//    paTextEdit.setColor(QPalette::Background, QColor(Qt::red));
//    pDTextEdit->setPalette(paTextEdit);

        pHBoxLayout->addStretch();
        pVBoxLayout->addLayout(pHBoxLayout);
        this->setLayout(pVBoxLayout);
}

PushButtonWidget::~PushButtonWidget()
{

}
