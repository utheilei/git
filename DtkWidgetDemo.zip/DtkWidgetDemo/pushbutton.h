#ifndef PUSHBUTTON_H
#define PUSHBUTTON_H

#include <QWidget>
#include <DPushButton>
#include <QVBoxLayout>
#include <DApplicationHelper>
#include <DTextEdit>
#include <QDebug>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class PushButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PushButtonWidget(QWidget *parent = nullptr);
    ~PushButtonWidget();

signals:

public slots:
};

#endif // PUSHBUTTON_H
