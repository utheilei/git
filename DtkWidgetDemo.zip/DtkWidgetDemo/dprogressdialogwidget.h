#ifndef DPROGRESSDIALOGWIDGET_H
#define DPROGRESSDIALOGWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
//#include <DProgressDialog>
#include <DDialog>
#include <DPushButton>
#include <QProgressDialog>
#include <QCoreApplication>
#include <QTimer>
#include <DProgressBar>

DWIDGET_USE_NAMESPACE

class DProgressDialogWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DProgressDialogWidget(QWidget *parent = nullptr);
    ~DProgressDialogWidget();

signals:

public slots:
    void slotDPubBtnClicked();
    void slotTimerout();

private:
    QTimer *m_pTimer;
    QProgressDialog *m_pProgressDialog;
    int m_iValue = 0;
};

#endif // DPROGRESSDIALOGWIDGET_H
