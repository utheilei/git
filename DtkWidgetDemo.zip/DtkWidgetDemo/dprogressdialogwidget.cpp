#include "dprogressdialogwidget.h"

DProgressDialogWidget::DProgressDialogWidget(QWidget *parent) : QWidget(parent)
{
    m_pTimer = new QTimer();
    m_pTimer->setInterval(100);
    connect(m_pTimer, &QTimer::timeout, this, &DProgressDialogWidget::slotTimerout);

    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("弹出DProgressDialog"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DProgressDialogWidget::slotDPubBtnClicked);
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DProgressBar *pDProgressBar = new DProgressBar();
   // pHBoxLayout2->addWidget(pDProgressBar)
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DProgressDialogWidget::~DProgressDialogWidget()
{

}

void DProgressDialogWidget::slotDPubBtnClicked()
{
    m_pTimer->start();
                                  //新建对象，参数含义：对话框正文，取消按钮名称，进度条范围
    m_pProgressDialog = new QProgressDialog(QString(tr("文件复制进度")), QString(tr("取消")), 0, 100, this);
    m_pProgressDialog->setMinimumWidth(500);
    m_pProgressDialog->setWindowTitle(QString(tr("进度提示")));
    m_pProgressDialog->setWindowModality(Qt::WindowModal); //模态对话框

    m_pProgressDialog->show();
}

void DProgressDialogWidget::slotTimerout()
{
    m_iValue += 1;
    if(m_iValue > 100)
    {
        m_iValue = 0;
        m_pTimer->stop();
    }

    m_pProgressDialog->setValue(m_iValue);
}
