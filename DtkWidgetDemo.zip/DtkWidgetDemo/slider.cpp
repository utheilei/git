#include "slider.h"

SliderWidgt::SliderWidgt(QWidget *parent)
            : QWidget (parent)
{
    QHBoxLayout *pMainHBoxLayout = new QHBoxLayout(this);
    pMainHBoxLayout->setSpacing(50);

    QVBoxLayout *pVBoxLayout = new QVBoxLayout();
    QHBoxLayout *pQHBoxLayout = new QHBoxLayout();
    pMainHBoxLayout->addLayout(pVBoxLayout, 7);
    pMainHBoxLayout->addLayout(pQHBoxLayout, 3);

    m_pLabel = new QLabel();
    m_pLabel->setMaximumWidth(100);
    m_pLabel->setMaximumHeight(100);
    pVBoxLayout->addWidget(m_pLabel);

    DSlider *pDSlider1 = new DSlider(Qt::Horizontal);
    pDSlider1->slider()->setMinimum(0);
    pDSlider1->slider()->setMaximum(100);
    pDSlider1->setValue(10);
    pDSlider1->setLeftIcon(QIcon(":/images/logo_24.svg"));
    pDSlider1->setRightIcon(QIcon(":/images/warning.svg"));
    pDSlider1->setIconSize(QSize(30, 30));
    pDSlider1->slider()->setTickPosition(QSlider::TicksBelow);
    connect(pDSlider1, &DSlider::valueChanged, this, &SliderWidgt::slotSliderValueChange, Qt::QueuedConnection);
    pVBoxLayout->addWidget(pDSlider1);

    DSlider *pDSlider2 = new DSlider(Qt::Horizontal);
    pDSlider2->slider()->setTickPosition(QSlider::TicksAbove);
    pDSlider2->slider()->setTickInterval(2);
    pDSlider2->slider()->setMinimum(0);
    pDSlider2->slider()->setMaximum(100);
    pVBoxLayout->addWidget(pDSlider2);

    DSlider *pDSlider3 = new DSlider(Qt::Horizontal);
    pDSlider3->slider()->setMinimum(0);
    pDSlider3->slider()->setMaximum(100);
    QStringList stringList;
    stringList << "1cm";
    stringList << "5cm";
    stringList << "10cm";
    stringList << "15cm";
    stringList << "20cm";
    pDSlider3->setAboveTicks(stringList);
    pDSlider3->setValue(10);
    connect(pDSlider3, &DSlider::valueChanged, this, &SliderWidgt::slotSliderValueChange, Qt::QueuedConnection);
    pVBoxLayout->addWidget(pDSlider3);

    DSlider *pDSlider4 = new DSlider(Qt::Vertical);
    pDSlider4->slider()->setMinimum(0);
    pDSlider4->slider()->setMaximum(100);
    pDSlider4->setValue(10);
    connect(pDSlider4, &DSlider::valueChanged, this, &SliderWidgt::slotSliderValueChange, Qt::QueuedConnection);
    pQHBoxLayout->addWidget(pDSlider4);

    DSlider *pDSlider5 = new DSlider(Qt::Vertical);
    pDSlider5->slider()->setTickPosition(QSlider::TicksAbove);
    pDSlider5->slider()->setTickInterval(2);
    pDSlider5->slider()->setMinimum(0);
    pDSlider5->slider()->setMaximum(100);
    pQHBoxLayout->addWidget(pDSlider5);

    DSlider *pDSlider6 = new DSlider(Qt::Vertical);
    //pDSlider2->slider()->setTickPosition(QSlider::TicksAbove);
    pDSlider6->slider()->setTickInterval(2);
    pDSlider6->slider()->setMinimum(0);
    pDSlider6->slider()->setMaximum(100);
    QStringList stringList1;
    stringList1 << "1cm";
    stringList1 << "5cm";
    stringList1 << "10cm";
    stringList1 << "15cm";
    stringList1 << "20cm";
    pDSlider6->setRightTicks(stringList);
    pDSlider6->setValue(10);
    connect(pDSlider6, &DSlider::valueChanged, this, &SliderWidgt::slotSliderValueChange, Qt::QueuedConnection);
    pQHBoxLayout->addWidget(pDSlider6);

    this->setLayout(pMainHBoxLayout);
}

SliderWidgt::~SliderWidgt()
{

}

void SliderWidgt::slotSliderValueChange(int value)
{
    QString strValue = QString("%1%2").arg(value).arg("%");
    m_pLabel->setText(strValue);
}
