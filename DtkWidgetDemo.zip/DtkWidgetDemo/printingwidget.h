#ifndef PRINTINGWIDGET_H
#define PRINTINGWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DPushButton>
#include <QPrintDialog>
#include <QPrintPreviewDialog>
#include <QPrinter>

DWIDGET_USE_NAMESPACE

class PrintingWidget : public QWidget
{
    Q_OBJECT
public:
    explicit PrintingWidget(QWidget *parent = nullptr);
    ~PrintingWidget();

signals:

public slots:
};

#endif // PRINTINGWIDGET_H
