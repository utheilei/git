#include "ddialogwidget.h"

DDialogWidget::DDialogWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("弹出DDialog"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DDialogWidget::slotDPubBtnClicked);
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    pHBoxLayout2->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout2);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DDialogWidget::~DDialogWidget()
{

}

void DDialogWidget::slotDPubBtnClicked()
{
    DDialog *pDDialog = new DDialog(QString(tr("保存提示")), QString(tr("您是否要保存此文件")), nullptr);
    pDDialog->setIcon(QIcon::fromTheme("deepin-editor"));
    pDDialog->setWindowFlags(pDDialog->windowFlags() | Qt::WindowStaysOnTopHint);
    pDDialog->addButton(QString(tr("取消")), false, DDialog::ButtonNormal);
    pDDialog->addButton(QString(tr("不保存")), false, DDialog::ButtonNormal);
    pDDialog->addButton(QString(tr("保存")), true, DDialog::ButtonNormal);
    pDDialog->show();

    DDialog *pDDialog2 = new DDialog(QString(tr("保存提示")), QString(tr("您是否要保存此文件")), nullptr);
    pDDialog2->setIcon(QIcon::fromTheme("deepin-editor"));
    pDDialog2->setWindowFlags(pDDialog->windowFlags() | Qt::WindowStaysOnTopHint);
    pDDialog2->addButton(QString(tr("取消")), false, DDialog::ButtonRecommend);
    pDDialog2->addButton(QString(tr("不保存")), false, DDialog::ButtonRecommend);
    pDDialog2->addButton(QString(tr("保存")), true, DDialog::ButtonRecommend);
    pDDialog2->show();

    DDialog *pDDialog3 = new DDialog(QString(tr("保存提示")), QString(tr("您是否要保存此文件")), nullptr);
    pDDialog3->setIcon(QIcon::fromTheme("deepin-editor"));
    pDDialog3->setWindowFlags(pDDialog->windowFlags() | Qt::WindowStaysOnTopHint);
    pDDialog3->addButton(QString(tr("取消")), false, DDialog::ButtonWarning);
    pDDialog3->addButton(QString(tr("不保存")), true, DDialog::ButtonWarning);
    pDDialog3->addButton(QString(tr("保存")), true, DDialog::ButtonWarning);
    pDDialog3->show();
}
