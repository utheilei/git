#ifndef DFRAMEWIDGET_H
#define DFRAMEWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DFrame>
#include <DPalette>
#include <DApplicationHelper>

DGUI_USE_NAMESPACE
DWIDGET_USE_NAMESPACE


class DFrameWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DFrameWidget(QWidget *parent = nullptr);
    ~DFrameWidget();

signals:

public slots:
};

#endif // DFRAMEWIDGET_H
