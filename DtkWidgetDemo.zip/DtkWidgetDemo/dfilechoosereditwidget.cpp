#include "dfilechoosereditwidget.h"

DFileChooserEditWidget::DFileChooserEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DFileChooserEdit *p = new DFileChooserEdit();
    p->setNameFilters(QStringList("file(*.cpp)"));
    pHBoxLayout->addWidget(p);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DFileChooserEditWidget::~DFileChooserEditWidget()
{

}
