#include "ddialwidget.h"

DDialWidget::DDialWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();

    DDial *pDDial1 = new DDial();
    pDDial1->setFixedSize(200, 200);
    pDDial1->setRange(0, 360);
    pHBoxLayout->addWidget(pDDial1);

    pHBoxLayout->addSpacing(20);
    DDial *pDDial2 = new DDial();
    pDDial2->setFixedSize(200, 200);
    pDDial2->setNotchesVisible(true);
    pHBoxLayout->addWidget(pDDial2);

    pHBoxLayout->addSpacing(20);
    QDial *pDial3 = new QDial();
    pDial3->setFixedSize(200, 200);
    pDial3->setNotchesVisible(true);
    pDial3->setMinimum(0);
    pDial3->setMaximum(59);
    pDial3->setNotchTarget(1);
    pHBoxLayout->addWidget(pDial3);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}

DDialWidget::~DDialWidget()
{

}
