#include "ddialogbuttonboxwidget.h"

DDialogButtonBoxWidget::DDialogButtonBoxWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    pVBoxLayout->setSpacing(20);
    pVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DPushButton *pDPusBtn = new DPushButton(tr("弹出DDialogButtonBox"));
    connect(pDPusBtn, &DPushButton::clicked, this, &DDialogButtonBoxWidget::slotDPubBtnClicked);
    pHBoxLayout->addWidget(pDPusBtn);
    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);

    pVBoxLayout->addStretch();
    this->setLayout(pVBoxLayout);
}

DDialogButtonBoxWidget::~DDialogButtonBoxWidget()
{

}

void DDialogButtonBoxWidget::slotDPubBtnClicked()
{
    DDialogButtonBox *pDDialogButtonBox = new DDialogButtonBox(DDialogButtonBox::YesToAll);
    pDDialogButtonBox->setCenterButtons(true);
    pDDialogButtonBox->addButton(QString(tr("确定")), DDialogButtonBox::YesRole);
    pDDialogButtonBox->addButton(QString(tr("取消")), DDialogButtonBox::ApplyRole);
    pDDialogButtonBox->show();
}
