#include "dsearcheditwidget.h"

DSearchEditWidget::DSearchEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(20);
    pMainVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    m_pDSearchEdit = new DSearchEdit();
    m_pDSearchEdit->setPlaceHolder(tr("fdgfdgfdg"));
    connect(m_pDSearchEdit, &DSearchEdit::textEdited, this, [=](QString strText) {
        qDebug() << "strText:" << strText;
    });
    connect(m_pDSearchEdit, &DSearchEdit::editingFinished, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("搜索“") + m_pDSearchEdit->text() + "”");
    });
    pHBoxLayout->addWidget(m_pDSearchEdit);
    pHBoxLayout->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout);


    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DPushButton *pDPushButton = new DPushButton(tr("应用"));
    pDPushButton->setFixedWidth(100);
    connect(pDPushButton, &DPushButton::clicked, this, &DSearchEditWidget::slotDPusBtnClicked);
    pHBoxLayout2->addWidget(pDPushButton);
    pHBoxLayout2->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout2);

    pMainVBoxLayout->addStretch();
    this->setLayout(pMainVBoxLayout);
}

DSearchEditWidget::~DSearchEditWidget()
{

}

void DSearchEditWidget::slotDPusBtnClicked()
{
    DMainWindow *w = new DMainWindow();
    w->titlebar()->addWidget(new DSearchEdit);
    w->show();
}

void DSearchEditWidget::slotDSearchTextEdit(const QString &strText)
{
    qDebug() << "strText:" << strText;
}

void DSearchEditWidget::slotEditingFinished()
{
    qDebug() << "In function [" << __FUNCTION__ << "].  " << m_pDSearchEdit->text();
}
