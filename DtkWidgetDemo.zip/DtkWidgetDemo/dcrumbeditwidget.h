#ifndef DCRUMBEDITWIDGET_H
#define DCRUMBEDITWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DCrumbEdit>

DWIDGET_USE_NAMESPACE

class DCrumbEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DCrumbEditWidget(QWidget *parent = nullptr);
    ~DCrumbEditWidget();

signals:

public slots:
};

#endif // DCRUMBEDITWIDGET_H
