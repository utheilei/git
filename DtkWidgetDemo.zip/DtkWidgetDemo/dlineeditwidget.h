#ifndef DLINEEDITWIDGET_H
#define DLINEEDITWIDGET_H

#include <QWidget>
#include <DApplicationHelper>
#include <DLineEdit>
#include <DFrame>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLayout>
#include <DPushButton>
#include <DIconButton>

DWIDGET_USE_NAMESPACE

class DLineEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DLineEditWidget(QWidget *parent = nullptr);
    ~DLineEditWidget();

signals:

public slots:
    void slotDpushBtnClicked();

private:
    DLineEdit *m_pDLineEdit3;
};

#endif // DLINEEDITWIDGET_H
