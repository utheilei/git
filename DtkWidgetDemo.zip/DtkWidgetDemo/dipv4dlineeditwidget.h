#ifndef DIPV4DLINEEDITWIDGET_H
#define DIPV4DLINEEDITWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DLineEdit>
#include <dipv4lineedit.h>
#include <DMessageManager>
#include <QDebug>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DIpv4DlineEditWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DIpv4DlineEditWidget(QWidget *parent = nullptr);
    ~DIpv4DlineEditWidget();

signals:

public slots:
};

#endif // DIPV4DLINEEDITWIDGET_H
