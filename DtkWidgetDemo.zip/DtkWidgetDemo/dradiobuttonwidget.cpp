#include "dradiobuttonwidget.h"

DRadioButtonWidget::DRadioButtonWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(10);

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(30);
    pHBoxLayout->addStretch();
    DCheckBox *pDCheckBox = new DCheckBox();
    pHBoxLayout->addWidget(pDCheckBox);
    DCheckBox *pDCheckBox2 = new DCheckBox();
    pDCheckBox2->setChecked(true);
    pHBoxLayout->addWidget(pDCheckBox2);
    DRadioButton *pDRadioButton = new DRadioButton();
    pHBoxLayout->addWidget(pDRadioButton);
    DRadioButton *pDRadioButton2 = new DRadioButton();
    pDRadioButton2->setChecked(true);
    pHBoxLayout->addWidget(pDRadioButton2);
    pHBoxLayout->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(30);
    pHBoxLayout2->addStretch();
    m_pDCheckBox3 = new DCheckBox(tr("未选择"));
    connect(m_pDCheckBox3, &DCheckBox::stateChanged, this, &DRadioButtonWidget::slotpDCheBox3StaChange);
    pHBoxLayout2->addWidget(m_pDCheckBox3);
    DCheckBox *pDCheckBox4 = new DCheckBox(tr("选中"));
    pDCheckBox4->setChecked(true);
    pHBoxLayout2->addWidget(pDCheckBox4);
    DRadioButton *pDRadioButton3 = new DRadioButton(tr("未选择"));
    pHBoxLayout2->addWidget(pDRadioButton3);
    DRadioButton *pDRadioButton4 = new DRadioButton(tr("选中"));
    pDRadioButton2->setChecked(true);
    pHBoxLayout2->addWidget(pDRadioButton4);
    pHBoxLayout2->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->setSpacing(30);
    pHBoxLayout3->addStretch();
    DCheckBox *pDCheckBox5 = new DCheckBox();
    pDCheckBox5->setIcon(QIcon(":/images/logo_24.svg"));
    pHBoxLayout3->addWidget(pDCheckBox5);
    connect(pDCheckBox5, &DCheckBox::stateChanged, this, [=](int iState) {
        if (iState == Qt::CheckState::Unchecked) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/warning.svg"), tr("取消选择"));
        }
        else if (iState == Qt::CheckState::Checked) {
            DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("选中"));
        }
    });

    DCheckBox *pDCheckBox6 = new DCheckBox();
    pDCheckBox6->setIcon(QIcon(":/images/warning.svg"));
    pDCheckBox6->setChecked(true);
    pHBoxLayout3->addWidget(pDCheckBox6);

    DRadioButton *pDRadioButton5 = new DRadioButton();
    pDRadioButton5->setIcon(QIcon(":/images/ok.svg"));
    pHBoxLayout3->addWidget(pDRadioButton5);
    DRadioButton *pDRadioButton6 = new DRadioButton();
    pDRadioButton6->setIcon(QIcon(":/images/logo_48.svg"));
    pDRadioButton6->setChecked(true);
    pHBoxLayout3->addWidget(pDRadioButton6);
    pHBoxLayout3->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout3);

    this->setLayout(pMainVBoxLayout);
}

DRadioButtonWidget::~DRadioButtonWidget()
{

}

void DRadioButtonWidget::slotpDCheBox3StaChange(int iState)
{
    qDebug() << __FUNCTION__ << "iState:" << iState;
    if(iState == Qt::CheckState::Unchecked)
    {
        m_pDCheckBox3->setText(tr("未选中"));
    }
    else if(iState == Qt::CheckState::Checked)
    {
        m_pDCheckBox3->setText(tr("选择"));
    }
}
