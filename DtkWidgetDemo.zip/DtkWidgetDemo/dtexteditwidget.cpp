#include "dtexteditwidget.h"

DTextEditWidget::DTextEditWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    //pHBoxLayout->addStretch();
    m_pDTextEdit = new DTextEdit1();
    m_pDTextEdit->setMinimumSize(300, 400);
    QFont font;
    font.setWeight(QFont::Weight::Normal);
    //font.setWeight(QFont::Weight::Medium);
    m_pDTextEdit->setFont(font);
    pHBoxLayout->addWidget(m_pDTextEdit->lineNumberArea);
    pHBoxLayout->addWidget(m_pDTextEdit);
    //pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DPushButton *pDPushBtn = new DPushButton(QStringLiteral("打开文件"));
    connect(pDPushBtn, &DPushButton::clicked, this, &DTextEditWidget::slotDPushBtnClicked);
    //pDTextEdit->setMinimumSize(100, 100);
    pHBoxLayout2->addWidget(pDPushBtn);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DTextEditWidget::~DTextEditWidget()
{

}

void DTextEditWidget::slotDPushBtnClicked()
{
    QString strFileName = QFileDialog::getOpenFileName();
    FileLoadThread *pFileLoadThread = new FileLoadThread(strFileName);
    connect(pFileLoadThread, &FileLoadThread::loadFinished, this, &DTextEditWidget::handleFileLoadFinished);
    pFileLoadThread->start();
}

void DTextEditWidget::handleFileLoadFinished(const QByteArray &encode, const QString &content)
{
    qDebug() << "content:" << content;
    m_pDTextEdit->setPlainText(content);
    m_pDTextEdit->update();
}
