#include "dtoolbuttonwidget.h"

DToolButtonWidget::DToolButtonWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(30);

    DToolButton *pDToolButton1 = new DToolButton();
    pDToolButton1->setText(tr("DToolButton"));
    connect(pDToolButton1, &DToolButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    pHBoxLayout->addWidget(pDToolButton1);

    DToolButton *pDToolButton2 = new DToolButton();
    pDToolButton2->setFixedSize(QSize(50, 50));
    pDToolButton2->setIcon(QIcon(":/images/d_normal.svg"));
    pDToolButton2->setIconSize(QSize(30, 30));
    connect(pDToolButton2, &DToolButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    pHBoxLayout->addWidget(pDToolButton2);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}
