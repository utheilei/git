#ifndef DGROUPBOXWIDGET_H
#define DGROUPBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DGroupBox>
#include <DCheckBox>
#include <DIconButton>
#include <DCommandLinkButton>
#include <DListWidget>
#include <DLabel>

DWIDGET_USE_NAMESPACE

class DGroupBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DGroupBoxWidget(QWidget *parent = nullptr);
    ~DGroupBoxWidget();

signals:

public slots:
};

#endif // DGROUPBOXWIDGET_H
