#ifndef DICONBUTTONWIDGET_H
#define DICONBUTTONWIDGET_H

#include <QObject>
#include <QWidget>
#include <DIconButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DFontSizeManager>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DIconButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DIconButtonWidget(QWidget *parent = nullptr);
    ~DIconButtonWidget();

signals:

public slots:
};

#endif // DICONBUTTONWIDGET_H
