#ifndef DTREEWIDGETWIDGET_H
#define DTREEWIDGETWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DTreeWidget>
#include <QTreeWidgetItem>

DWIDGET_USE_NAMESPACE

class DTreeWidgetWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DTreeWidgetWidget(QWidget *parent = nullptr);
    ~DTreeWidgetWidget();

signals:

public slots:
};

#endif // DTREEWIDGETWIDGET_H
