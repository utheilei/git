#ifndef DCOMMANDLINKBTUUONWIDGET_H
#define DCOMMANDLINKBTUUONWIDGET_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DCommandLinkButton>
#include <DMessageManager>
//#include <DFloatingMessage>

DWIDGET_USE_NAMESPACE

class DCommandLinkButtonWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DCommandLinkButtonWidget(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DCOMMANDLINKBTUUONWIDGET_H
