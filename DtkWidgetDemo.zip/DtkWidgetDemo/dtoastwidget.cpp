#include "dtoastwidget.h"

DToastWidget::DToastWidget(QWidget *parent) : QWidget(parent)
{
    DToast *pDToast = new DToast(this);
    pDToast->setText(QStringLiteral("成功发布“校园民谣”"));
    pDToast->pop();

    QFont font;
    font.setPixelSize(13);

    QVBoxLayout *pMainLayout = new QVBoxLayout();
    pMainLayout->setSpacing(20);
    pMainLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->setSpacing(0);
    pHBoxLayout->addStretch();
    DPushButton *pDPushButton = new DPushButton(QStringLiteral("临时DMessageManager::sendMessage"));
    //pDPushButton->setFixedSize(150, 36);
    connect(pDPushButton, &DPushButton::clicked, this, &DToastWidget::slotDPuBtnClicked);
    pHBoxLayout->addWidget(pDPushButton);
    pHBoxLayout->addStretch();
    pMainLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout1 = new QHBoxLayout();
    pHBoxLayout1->setSpacing(0);
    pHBoxLayout1->addStretch();
    DPushButton *pDPushButton1 = new DPushButton(QStringLiteral("临时DFloatingMessage"));
    //pDPushButton->setFixedSize(150, 36);
    connect(pDPushButton1, &DPushButton::clicked, this, &DToastWidget::slotDPuBtn2Clicked);
    pHBoxLayout1->addWidget(pDPushButton1);
    pHBoxLayout1->addStretch();
    pMainLayout->addLayout(pHBoxLayout1);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->setSpacing(0);
    pHBoxLayout2->addStretch();
    DFloatingMessage *pDFloatMessage = new DFloatingMessage(DFloatingMessage::ResidentType, this);
    pDFloatMessage->setMinimumHeight(50);
    pDFloatMessage->setFont(font);
    pDFloatMessage->setIcon(QIcon(":/images/ok.svg"));
    pDFloatMessage->setMessage(QStringLiteral("成功发布“校园民谣”"));
    pDFloatMessage->show();
    pHBoxLayout2->addWidget(pDFloatMessage);
    pHBoxLayout2->addStretch();
    pMainLayout->addLayout(pHBoxLayout2);

    QHBoxLayout *pHBoxLayout3 = new QHBoxLayout();
    pHBoxLayout3->setSpacing(0);
    pHBoxLayout3->addStretch();
    m_pDFloatMessage2 = new DFloatingMessage(DFloatingMessage::TransientType, this);
    m_pDFloatMessage2->setIcon(QIcon(":/images/ok.svg"));
    m_pDFloatMessage2->setMinimumHeight(50);
    m_pDFloatMessage2->setFont(font);
    m_pDFloatMessage2->setMessage(QStringLiteral("文件已保存"));
    m_pDFloatMessage2->hide();
    pHBoxLayout3->addWidget(m_pDFloatMessage2);
    pHBoxLayout3->addStretch();
    pMainLayout->addLayout(pHBoxLayout3);

    QHBoxLayout *pHBoxLayout4 = new QHBoxLayout();
    pHBoxLayout4->setSpacing(0);
    pHBoxLayout4->addStretch();
    m_pDFloatMessage3 = new DFloatingMessage(DFloatingMessage::ResidentType, this);
    m_pDFloatMessage3->setIcon(QIcon(":/images/warning.svg"));
    m_pDFloatMessage3->setFont(font);
    m_pDFloatMessage3->setMessage(QStringLiteral("磁盘的原文件已经被修改，是否重新载入？"));
    DPushButton *pDPushBtn = new DPushButton(QStringLiteral("重新载入"));
    m_pDFloatMessage3->setWidget(pDPushBtn);
    pHBoxLayout4->addWidget(m_pDFloatMessage3);
    pHBoxLayout4->addStretch();
    pMainLayout->addLayout(pHBoxLayout4);

    pMainLayout->addStretch();
    this->setLayout(pMainLayout);
}

DToastWidget::~DToastWidget()
{

}

void DToastWidget::slotDPuBtnClicked()
{
    DMessageManager::instance()->sendMessage(this->window(), QIcon(":/images/ok.svg"), QStringLiteral("成功发布“校园民谣”"));
}

void DToastWidget::slotDPuBtn2Clicked()
{
    m_pDFloatMessage2->show();
}
