#ifndef DDIALOGBUTTONBOXWIDGET_H
#define DDIALOGBUTTONBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DDialogButtonBox>
#include <DPushButton>

DWIDGET_USE_NAMESPACE

class DDialogButtonBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DDialogButtonBoxWidget(QWidget *parent = nullptr);
    ~DDialogButtonBoxWidget();

signals:

public slots:
    void slotDPubBtnClicked();
};

#endif // DDIALOGBUTTONBOXWIDGET_H
