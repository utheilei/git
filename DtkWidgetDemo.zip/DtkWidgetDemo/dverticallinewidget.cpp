#include "dverticallinewidget.h"

DVerticalLineWidget::DVerticalLineWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pMainVBoxLayout = new QVBoxLayout(this);
    pMainVBoxLayout->setSpacing(20);
    pMainVBoxLayout->addStretch();

    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    DVerticalLine *pDVerticalLine = new DVerticalLine();
    //pDVerticalLine->setFixedSize(10, 200);
    pDVerticalLine->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
    pDVerticalLine->setBackgroundRole(QPalette::Highlight);
    pDVerticalLine->setAutoFillBackground(true);
//    DPalette pa = DApplicationHelper::instance()->palette(pDVerticalLine);
//    QColor color = pa.highlight().color();
//    pa.setColor(DPalette::WindowText, color);
//    pDVerticalLine->setPalette(pa);
    pHBoxLayout->addWidget(pDVerticalLine);
    pHBoxLayout->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout);

    QHBoxLayout *pHBoxLayout2 = new QHBoxLayout();
    pHBoxLayout2->addStretch();
    DHorizontalLine *pDHorizontalLine = new DHorizontalLine();
    pDHorizontalLine->setFixedSize(400, 2);
    pDHorizontalLine->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
    pDHorizontalLine->setBackgroundRole(QPalette::Highlight);
    pDHorizontalLine->setAutoFillBackground(true);
    pHBoxLayout2->addWidget(pDHorizontalLine);
    pHBoxLayout2->addStretch();
    pMainVBoxLayout->addLayout(pHBoxLayout2);

    pMainVBoxLayout->addStretch();
    this->setLayout(pMainVBoxLayout);
}

DVerticalLineWidget::~DVerticalLineWidget()
{

}
