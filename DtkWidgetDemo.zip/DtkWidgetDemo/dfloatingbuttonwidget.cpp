#include "dfloatingbuttonwidget.h"

DFloatingButtonWidget::DFloatingButtonWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *pVBoxLayout = new QVBoxLayout(this);
    QHBoxLayout *pHBoxLayout = new QHBoxLayout();
    pHBoxLayout->addStretch();
    pHBoxLayout->setSpacing(20);

    DFloatingButton *pDFloatingButtonAdd = new DFloatingButton(DStyle::SP_DeleteButton);
    connect(pDFloatingButtonAdd, &DFloatingButton::clicked, this, [=] {
        DMessageManager::instance()->sendMessage(this, QIcon(":/images/ok.svg"), tr("点击"));
    });
    //需要制定背景颜色角色才能生效
    pDFloatingButtonAdd->setBackgroundRole(QPalette::Button);
    DPalette pa = DApplicationHelper::instance()->palette(pDFloatingButtonAdd);
    QColor color = pa.lightLively().color();
    pa.setColor(QPalette::Button, color);
    pDFloatingButtonAdd->setPalette(pa);
    pDFloatingButtonAdd->setFixedSize(100, 100);
    pDFloatingButtonAdd->setIconSize(QSize(50, 50));
    pHBoxLayout->addWidget(pDFloatingButtonAdd);

    DFloatingButton *pDSuggestButtonDelete = new DFloatingButton(DStyle::SP_DeleteButton);
    pDSuggestButtonDelete->setMaximumWidth(100);
    pHBoxLayout->addWidget(pDSuggestButtonDelete);
    pDSuggestButtonDelete->setDisabled(true);

    DFloatingButton *pDSuggestButtonSear = new DFloatingButton(QIcon(":/images/ok.svg"), tr("正确"));
    pDSuggestButtonSear->setMinimumSize(100, 100);
    pHBoxLayout->addWidget(pDSuggestButtonSear);
    pDSuggestButtonSear->setFocusPolicy(Qt::StrongFocus);

    DFloatingButton *pDSuggestButtonClose = new DFloatingButton(nullptr);
    pDSuggestButtonClose->setFixedSize(100, 100);
    pDSuggestButtonClose->setIcon(QIcon(":/images/logo_24.svg"));
    pDSuggestButtonClose->setIconSize(QSize(50, 50));
    pHBoxLayout->addWidget(pDSuggestButtonClose);

    pHBoxLayout->addStretch();
    pVBoxLayout->addLayout(pHBoxLayout);
    this->setLayout(pVBoxLayout);
}
