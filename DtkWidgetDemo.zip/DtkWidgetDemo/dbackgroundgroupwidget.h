#ifndef DBACKGROUNDGROUPWIDGET_H
#define DBACKGROUNDGROUPWIDGET_H

#include <QWidget>
#include <DBackgroundGroup>
#include <DPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <DPalette>
#include <DApplicationHelper>
#include <QDebug>

DGUI_USE_NAMESPACE
DWIDGET_USE_NAMESPACE

class DBackgroundGroupWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DBackgroundGroupWidget(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // DBACKGROUNDGROUPWIDGET_H
