#ifndef DBUTTONBOXWIDGET_H
#define DBUTTONBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DButtonBox>
#include <QStyle>
#include <DPushButton>
#include <DMainWindow>
#include <DTitlebar>
#include <DMessageManager>

DWIDGET_USE_NAMESPACE

class DButtonBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DButtonBoxWidget(QWidget *parent = nullptr);
    ~DButtonBoxWidget();

signals:

public slots:
    void slotDBtnClicked();

private:
    DButtonBox *pDButtonBox;
    DButtonBox *m_pDButtonBox2;
};

#endif // DBUTTONBOXWIDGET_H
