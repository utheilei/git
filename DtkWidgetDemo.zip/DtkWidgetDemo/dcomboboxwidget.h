#ifndef DCOMBOBOXWIDGET_H
#define DCOMBOBOXWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <DComboBox>
#include <DDial>

DWIDGET_USE_NAMESPACE

class DComboBoxWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DComboBoxWidget(QWidget *parent = nullptr);
    ~DComboBoxWidget();

signals:

public slots:
};

#endif // DCOMBOBOXWIDGET_H
